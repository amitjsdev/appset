<?php
function appset_child_enqueue_styles() {
    //wp_dequeue_style( 'appset-google-fonts' );
    $parent_style = 'appset-style';

    if( function_exists('is_woocommerce') ){
    	$dependency = array('bootstrap', 'appset-woocommerce', 'appset-default-style');
    }else{
    	$dependency = array('bootstrap', 'appset-default-style');
    }

    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css', $dependency );
    wp_enqueue_style( 'appset-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style )
    );

   
}
add_action( 'wp_enqueue_scripts', 'appset_child_enqueue_styles' );
<?php
add_action( 'vc_load_default_templates_action','appset_section_brands_for_vc' ); // Hook in
function appset_section_brands_for_vc() {
	$templates = array();
	$templates['Section: Brands 01'] = '[vc_section section_type="brands" brands_type="1" bg_class="bg-lightgrey" parallax_image_attachment="inherit" padding_class=""][vc_row parallax_image_attachment="inherit"][vc_column width="1/12"][/vc_column][vc_column width="5/6"][perch_section_title title="We partner with companies of all sizes, all around the world" title_font_container="tag:p|size:lg|text_color:grey-color|text_underline:none|" subtitle="" mbottom="mb-0"][perch_vc_carousel cacrousel_style="" column_lg="4" column_md="4" column_sm="3" dots="0"][perch_brand_logo custom_src="'.get_template_directory_uri().'/images/brand-1.png"][perch_brand_logo custom_src="'.get_template_directory_uri().'/images/brand-2.png"][perch_brand_logo custom_src="'.get_template_directory_uri().'/images/brand-3.png"][perch_brand_logo custom_src="'.get_template_directory_uri().'/images/brand-5.png"][/perch_vc_carousel][/vc_column][vc_column width="1/12"][/vc_column][/vc_row][/vc_section]';

	$templates['Section: Brands 02'] = '[vc_section section_type="brands" brands_type="2" bg_class="bg-lightgrey" parallax_image_attachment="fixed" padding_class="wide-100"][vc_row parallax_image_attachment="inherit"][vc_column][perch_section_title title="We partner with companies of all sizes, all around the world" title_font_container="tag:p|size:lg|text_color:grey-color|text_underline:none|" subtitle=""][perch_vc_carousel cacrousel_style="" column_lg="5" column_md="5" column_sm="3" dots="0"][perch_brand_logo custom_src="'.get_template_directory_uri().'/images/brand-3.png"][perch_brand_logo custom_src="'.get_template_directory_uri().'/images/brand-4.png"][perch_brand_logo custom_src="'.get_template_directory_uri().'/images/brand-5.png"][perch_brand_logo custom_src="'.get_template_directory_uri().'/images/brand-6.png"][perch_brand_logo custom_src="'.get_template_directory_uri().'/images/brand-7.png"][/perch_vc_carousel][/vc_column][/vc_row][/vc_section]';




	
	foreach ($templates as $key => $template) {
		$data               = array(); 
	    $data['name']       = esc_attr($key); // Assign name for your custom template
	    $data['weight']     = 0; 
	    $data['image_path'] = '';
	    $data['custom_class'] = ''; // CSS class name
	    $data['content']    = $template;

	    vc_add_default_templates( $data );
	}
      

}




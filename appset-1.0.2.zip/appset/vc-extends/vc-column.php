<?php
add_action( 'vc_after_init', 'appset_vc_column_settings' );
function appset_vc_column_settings() {
    $newParamData = array( 
        array(
             'type' => 'dropdown',
            'heading' => __( 'Predefined Column class', 'appset' ),
            'param_name' => 'column_inner_style',
            'group' => 'Appset Settings',
            'value' => appset_vc_column_class_options(),
            'std' => '',
            'description' => '',            
        ), 
        appset_vc_column_type_params('hero_type', 'Hero style', 12, 'hero-img'), 
        appset_vc_column_type_params('hero_txt_type', 'Hero style', 12, 'hero-txt'), 
        appset_vc_column_type_params('content_img_type', 'Content style', 12, 'content-img'), 
        appset_vc_column_type_params('content_txt_type', 'Content style', 12, 'content-txt'), 
        appset_vc_column_type_params('download_img_type', 'Download style', 12, 'download-img'), 
        array(
             'group' => 'Appset Settings',
            'type' => 'dropdown',
            'heading' => __( 'Border color', 'appset' ),
            'param_name' => 'rounded_color',
            'std' => 'preset',
            'value' => appset_vc_color_options(true),
            'dependency' => array(
                'element' => 'column_inner_style',
                'value' => 'box-rounded',
            )
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Column Background', 'appset' ),
            'param_name' => 'column_bg_class',
            'group' => 'Appset Settings',
            'value' => appset_vc_background_options(),
            'std' => 'bg-tra',
            'description' => '' 
        )
         
    );
    foreach ( $newParamData as $key => $value ) {
        vc_update_shortcode_param( 'vc_column', $value );
        vc_update_shortcode_param( 'vc_column_inner', $value );
    }     

    
}


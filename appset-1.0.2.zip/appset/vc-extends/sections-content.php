<?php
add_action( 'vc_load_default_templates_action','appset_content_sections_for_vc' ); // Hook in
function appset_content_sections_for_vc() {
	$templates = array();

	$templates['Section: Content 01'] = '[vc_section section_type="content" content_type="1" parallax_image_attachment="inherit"][vc_row parallax_image_attachment="inherit"][vc_column width="1/2"][perch_content_text name="" enable_content="" enable_content_list="yes" enable_counter_group="yes" counter_group="%5B%7B%22prefix%22%3A%223%2C%22%2C%22count%22%3A%22438%22%2C%22counter_color%22%3A%22coral-color%22%2C%22title%22%3A%22Downloads%22%7D%2C%7B%22prefix%22%3A%221%2C%22%2C%22count%22%3A%22263%22%2C%22counter_color%22%3A%22coral-color%22%2C%22title%22%3A%22Tickets%20Closed%22%7D%5D"][/perch_content_text][/vc_column][vc_column width="1/12"][/vc_column][vc_column width="5/12"][perch_image custom_src="'.get_template_directory_uri().'/images/image-05.png" css_animation="fadeInRight"][/vc_column][/vc_row][/vc_section]';

	$templates['Section: Content 01 Style 2'] = '[vc_section section_type="content" content_type="1" parallax_image_attachment="inherit"][vc_row parallax_image_attachment="inherit"][vc_column width="1/2"][perch_content_text name="" title="We use design and innovations" subtitle="An enim nullam tempor sapien gravida donec enim ipsum pretium porta justo integer at odio velna vitae auctor integer congue magna at purus pretium ligula rutrum luctus risus ultrice enim gravida" enable_content="" enable_content_list="yes" content_list="Vitae auctor integer congue magna at pretium purus,Vitae auctor integer congue magna at pretium purus pretium ligula rutrum luctus risus enim ipsum blandit" enable_counter_group="yes" counter_group="%5B%7B%22prefix%22%3A%223%2C%22%2C%22count%22%3A%22438%22%2C%22counter_color%22%3A%22coral-color%22%2C%22title%22%3A%22Downloads%22%7D%2C%7B%22prefix%22%3A%221%2C%22%2C%22count%22%3A%22263%22%2C%22counter_color%22%3A%22coral-color%22%2C%22title%22%3A%22Tickets%20Closed%22%7D%5D"][/perch_content_text][/vc_column][vc_column width="1/12"][/vc_column][vc_column width="5/12"][perch_image custom_src="'.get_template_directory_uri().'/images/image-06.png"][/vc_column][/vc_row][/vc_section]';


	$templates['Section: Content 02'] = '[vc_section section_type="content" content_type="2" parallax_image_attachment="inherit"][vc_row parallax_image_attachment="inherit"][vc_column width="5/12"][perch_image custom_src="'.get_template_directory_uri().'/images/image-06.png"][/vc_column][vc_column width="1/12"][/vc_column][vc_column width="1/2"][perch_content_text name="We bring the best design for you" name_font_container="tag:h3|size:xl|text_color:Default|text_underline:none|extra_class:section-id|" title=" Semper lacus cursus porta, feugiat primis in ultrice ligula tempus auctor ipsum and mauris lectus enim ipsum enim gravida purus pretium ligula " title_font_container="tag:p|size:md|text_color:Default|text_underline:none|" subtitle=" Feature Integration" subtitle_font_container="tag:h5|size:sm|text_color:Default|text_underline:none|"]An nullam tempor sapien, eget gravida donec enim ipsum porta justo integer at odio velna vitae auctor integer congue. Justo at odio integer velna vitae auctor integer congue magna impedit

		Semper lacus cursus porta primis ligula risus tempus auctor ipsum and mauris lectus purus tempor ipsum cursus[/perch_content_text][/vc_column][/vc_row][/vc_section]';

	$templates['Section: Content 03'] = '[vc_section section_type="content" content_type="3" parallax_image_attachment="inherit"][vc_row parallax_image_attachment="inherit"][vc_column width="1/2"][perch_content_text name="" title="Showcase your App in the right way" subtitle="An enim nullam tempor sapien gravida donec enim ipsum pretium porta justo integer at odio velna vitae auctor integer congue magna at purus pretium ligula rutrum luctus risus ultrice enim gravida" enable_content="" enable_content_list="yes" content_list="Vitae auctor integer congue magna at pretium purus,Vitae auctor integer congue magna at pretium purus pretium ligula rutrum luctus risus" enable_counter_group="yes" counter_group="%5B%7B%22prefix%22%3A%223%2C%22%2C%22count%22%3A%22438%22%2C%22counter_color%22%3A%22coral-color%22%2C%22title%22%3A%22Downloads%22%7D%2C%7B%22prefix%22%3A%221%2C%22%2C%22count%22%3A%22263%22%2C%22counter_color%22%3A%22coral-color%22%2C%22title%22%3A%22Tickets%20Closed%22%7D%5D"][/perch_content_text][/vc_column][vc_column width="1/12"][/vc_column][vc_column width="5/12"][perch_image custom_src="'.get_template_directory_uri().'/images/image-01.png"][/vc_column][/vc_row][/vc_section]';

	$templates['Section: Content 04'] = '[vc_section parallax_image_attachment="inherit" padding_top="pt-100" padding_class=""][vc_row][vc_column width="1/2"][perch_image custom_src="'.get_template_directory_uri().'/images/image-08.png"][/vc_column][vc_column width="1/2"][perch_content_text name="" title="Stunning landing page for your App" subtitle="An nullam tempor sapien, eget gravida donec enim ipsum porta justo integer at odio velna vitae auctor integer congue. Justo at odio integer velna vitae auctor cursus porta feugiat" enable_content="" enable_content_list="yes"][/perch_content_text][/vc_column][/vc_row][/vc_section]';

	$templates['Section: Content 04 Parallax'] = '[vc_section section_type="content" parallax_image="http://localhost/appset/files/images/content-bg-image.jpg" parallax="content-moving" parallax_speed_bg="1.0" content_type="4" bg_class="bg-tra" parallax_image_attachment="fixed" padding_top="pt-100" padding_class="" parallax_image_repeat="" parallax_image_position="50% 0" el_class="bg-image"][vc_row parallax_image_attachment="inherit" el_class="white-color"][vc_column width="1/2"][perch_image custom_src="'.get_template_directory_uri().'/images/image-08.png"][/vc_column][vc_column width="1/2"][perch_content_text name="" title="The easy App for creativity & design" subtitle="An nullam tempor sapien, eget gravida donec enim ipsum porta justo integer at odio velna vitae auctor integer congue. Justo at odio integer velna vitae auctor cursus porta feugiat" enable_content="" enable_content_list="yes"][/perch_content_text][/vc_column][/vc_row][/vc_section]';

	$templates['Section: Content 05'] = '[vc_section enable_inner="yes" section_type="content" content_type="5" inner_bg_class="bg-lightgrey" inner_padding_top="pt-100" bg_class="bg-tra" parallax_image_attachment="scroll" padding_bottom="pb-80" padding_class=""][vc_row][vc_column width="5/12"][perch_image custom_src="'.get_template_directory_uri().'/images/image-02.png"][/vc_column][vc_column width="1/12"][/vc_column][vc_column width="1/2"][perch_content_text name="We bring the best things for you" name_font_container="tag:h3|size:xl|text_color:Default|text_underline:none|extra_class:section-id|" title="Semper lacus cursus porta, feugiat primis in ultrice ligula tempus auctor ipsum and mauris lectus enim ipsum" title_font_container="tag:p|size:md|text_color:Default|text_underline:none|" subtitle="Feature Integration" subtitle_font_container="tag:h5|size:sm|text_color:Default|text_underline:none|"]

		An nullam tempor sapien, eget gravida donec enim ipsum porta justo integer at odio velna vitae auctor integer congue. Justo at odio integer velna vitae auctor integer congue magna impedit

		Semper lacus cursus porta primis ligula risus tempus auctor ipsum and mauris lectus purus tempor ipsum cursus

		[/perch_content_text][/vc_column][/vc_row][/vc_section]';

	$templates['Section: Content 06'] = '[vc_section enable_inner="yes" section_type="content" content_type="6" inner_bg_class="bg-lightgrey" inner_padding_bottom="pb-100" parallax_image_attachment="scroll" padding_top="pt-100" padding_class=""][vc_row][vc_column width="1/2"][perch_content_text name="Our success is measured by result" name_font_container="tag:h3|size:xl|text_color:Default|text_underline:none|extra_class:section-id|" title="Semper lacus cursus porta feugiat primis in ultrice tempus ligula auctor ipsum and mauris lectus ipsum" title_font_container="tag:p|size:md|text_color:Default|text_underline:none|" subtitle="Feature Integration" subtitle_font_container="tag:h5|size:sm|text_color:Default|text_underline:none|" enable_content="" enable_content_list="yes" content_list="Vitae auctor integer congue magna at pretium purus,Vitae auctor integer congue magna at pretium purus pretium ligula rutrum luctus risus enim ipsum blandit,Magna at pretium purus pretium ligula rutrum"][/perch_content_text][/vc_column][vc_column width="1/12"][/vc_column][vc_column width="5/12"][perch_image custom_src="'.get_template_directory_uri().'/images/image-01.png"][/vc_column][/vc_row][/vc_section]';

	$templates['Section: Content 07'] = '[vc_section section_type="content" content_type="7" parallax_image_attachment="inherit"][vc_row][vc_column width="7/12"][perch_content_text name="" title="Organize all your media content with AppSet easily" subtitle="Semper lacus cursus porta, feugiat primis in ultrice ligula tempus auctor ipsum and mauris lectus enim ipsum" subtitle_font_container="tag:p|size:md|text_color:grey-color|text_underline:none|" enable_app_devices="yes"]

		An nullam tempor sapien, eget gravida donec enim ipsum porta justo integer at odio velna vitae auctor integer congue. Justo at odio integer velna vitae auctor integer congue magna impedit

		Semper lacus cursus porta primis ligula risus tempus sagittis ipsum and mauris lectus purus tempor ipsum at enim ipsum porta

		[/perch_content_text][/vc_column][vc_column width="1/12"][/vc_column][vc_column width="4/12"][perch_image custom_src="'.get_template_directory_uri().'/images/image-07.png" max_width="yes"][/vc_column][/vc_row][/vc_section]';

	$templates['Section: Content 08'] = '[vc_section section_type="content" content_type="8" parallax_image_attachment="inherit"][vc_row][vc_column width="1/2"][perch_content_text name="" title="AppSet makes you surprised" subtitle="An enim nullam tempor sapien gravida donec enim ipsum porta pretium justo integer at odio velna vitae auctor integer congue magna at purus pretium ligula rutrum luctus risus ultrice" enable_content="" enable_content_list="yes"][/perch_content_text][/vc_column][vc_column width="1/2"][perch_image custom_src="'.get_template_directory_uri().'/images/image-10.jpg" onclick="video"][/vc_column][/vc_row][/vc_section]';	

	$templates['Section: Content 09'] = '[vc_section section_type="content" content_type="9" parallax_image_attachment="inherit" padding_top="pt-100" padding_class=""][vc_row parallax_image_attachment="inherit"][vc_column][perch_section_title title="Beautiful User Interface" subtitle="Gravida donec integer ipsum porta justo at odio velna vitae auctor integer magna at risus auctor purus rutrum primis ultrice ligula luctus impedit magna dolor vitae risuss"][perch_image custom_src="'.get_template_directory_uri().'/images/image-12.png"][/vc_column][/vc_row][/vc_section]';






	
	foreach ($templates as $key => $template) {
		$data               = array(); 
	    $data['name']       = esc_attr($key); // Assign name for your custom template
	    $data['weight']     = 0; 
	    $data['image_path'] = '';
	    $data['custom_class'] = ''; // CSS class name
	    $data['content']    = $template;

	    vc_add_default_templates( $data );
	}
      

}




<?php
add_filter( 'perch_modules/vc/perch_counter_up', 'appset_vc_counter_up_default_args', 30, 1 );
function appset_vc_counter_up_default_args( $args ){
	$default = array(
		'icon_tonicons' => 'ti-Line-Coffee-mug',
		'icon_color' => 'green-color',
		'title' => 'Cups of Coffee',
		'title_font_container' => 'tag:p|text_color:txt-500',        
        'subtitle' => '',
        'subtitle_font_container' => 'tag:p',  
        'el_class' => 'statistic-block box-icon'       
    );

    $args = appset_set_default_vc_values($default, $args);   
    
    return $args;    
}
<?php
add_filter( 'perch_modules/vc/perch_pricing_table', 'appset_vc_pricing_table_default_args' );
function appset_vc_pricing_table_default_args( $args ){
	$default = array(
		'align' => '',              
        'title' => 'Agency', 
        'title_font_container' => 'tag:h5|size:lg',
        'validity' => 'monthly', 
        'validity_font_container' => 'tag:p|extra_class:validity',
        'leadtext' => '',
        'subtitle_font_container' => 'tag:p|size:md',    
        'el_class' => '',       
    );

    $args = appset_set_default_vc_values($default, $args);   
    
    return $args;    
}
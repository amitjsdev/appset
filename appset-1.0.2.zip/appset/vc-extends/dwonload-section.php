<?php
add_action( 'vc_load_default_templates_action','appset_dwonload_sections_for_vc' ); // Hook in
function appset_dwonload_sections_for_vc() {
	$templates = array();
	$templates['Section: Download 02'] = '[vc_section parallax_image="'.get_template_directory_uri().'/images/download-2.jpg" parallax="content-moving" parallax_speed_bg="1.0" bg_class="bg-tra" parallax_image_attachment="inherit" padding_class="wide-100" parallax_image_repeat="" parallax_image_position="50% 0"][vc_row parallax_image_attachment="inherit" el_class="white-color"][vc_column][perch_section_title title="What are you waiting for?" subtitle="Feugiat eros, ac tincidunt ligula massa in faucibus orci luctus et ultrices posuere cubilia curae integer congue metus mollis lorem primis mollis" title_font_container="tag:h2|size:lg|text_underline:None|" animation="none" css=".vc_custom_1548146764407{margin-bottom: 0px !important;}"][perch_buttons_group params="%5B%7B%22button_type%22%3A%22img_btn%22%2C%22img_btn%22%3A%22http%3A%2F%2Flocalhost%2Fappset%2Ffiles%2Fimages%2Fstore_badges%2Fappstore-tra-white.png%22%2C%22img_btn_size%22%3A%22160%22%2C%22button_text%22%3A%22appstore%22%2C%22button_url%22%3A%22%23%22%2C%22icon_fontawesome%22%3A%22fa%20fa-angle-double-right%22%2C%22button_target%22%3A%22_blank%22%2C%22button_style%22%3A%22Transparent%20white%22%7D%2C%7B%22button_type%22%3A%22img_btn%22%2C%22img_btn%22%3A%22http%3A%2F%2Flocalhost%2Fappset%2Ffiles%2Fimages%2Fstore_badges%2Fgoogleplay-tra-white.png%22%2C%22img_btn_size%22%3A%22160%22%2C%22button_text%22%3A%22Googleplay%22%2C%22button_url%22%3A%22%23%22%2C%22icon_fontawesome%22%3A%22fa%20fa-angle-double-right%22%2C%22button_target%22%3A%22_blank%22%2C%22button_style%22%3A%22Transparent%20white%22%7D%5D" footer="" el_class="text-center"][/vc_column][/vc_row][/vc_section]';






	
	foreach ($templates as $key => $template) {
		$data               = array(); 
	    $data['name']       = esc_attr($key); // Assign name for your custom template
	    $data['weight']     = 0; 
	    $data['image_path'] = '';
	    $data['custom_class'] = ''; // CSS class name
	    $data['content']    = $template;

	    vc_add_default_templates( $data );
	}
      

}
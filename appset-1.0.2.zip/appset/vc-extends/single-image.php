<?php
add_action( 'vc_after_init', 'appset_hero_image_shortcode_vc' );
function appset_hero_image_shortcode_vc() {

	$args = array(
		'name' => __( 'Single Image', 'appset' ),
		'base' => 'vc_single_image',
		'icon' => 'appset-icon',
		'category' => __( 'Appset', 'appset' ),
		'description' => __( 'Simple image with CSS animation', 'appset' ),
		'params' => array(			
			array(
				'type' => 'dropdown',
				'heading' => __( 'Image source', 'appset' ),
				'param_name' => 'source',
				'std' => 'external_link',
				'value' => array(
					__( 'Media library', 'appset' ) => 'media_library',
					__( 'External link', 'appset' ) => 'external_link',
					__( 'Featured Image', 'appset' ) => 'featured_image',
				),
				'description' => __( 'Select image source.', 'appset' ),
			),
			array(
				'type' => 'attach_image',
				'heading' => __( 'Image', 'appset' ),
				'param_name' => 'image',
				'value' => '',
				'description' => __( 'Select image from media library.', 'appset' ),
				'dependency' => array(
					'element' => 'source',
					'value' => 'media_library',
				),
				'admin_label' => true,
			),
			array(
				'type' => 'image_upload',
				'heading' => __( 'External link', 'appset' ),
				'param_name' => 'custom_src',
				'value' => APPSET_URI. '/images/image-01.png',
				'description' => __( 'Select external link.', 'appset' ),
				'dependency' => array(
					'element' => 'source',
					'value' => 'external_link',
				),
				'admin_label' => true,
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Image size', 'appset' ),
				'param_name' => 'img_size',
				'std' => 'full',
				'value' => array_flip( appset_get_image_sizes_Arr() ),
				'description' => __( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'appset' ),
				'dependency' => array(
					'element' => 'source',
					'value' => array(
						'media_library',
						'featured_image',
					),
				),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Image size', 'appset' ),
				'param_name' => 'external_img_size',
				'value' => '',
				'description' => __( 'Enter image size in pixels. Example: 200x100 (Width x Height).', 'appset' ),
				'dependency' => array(
					'element' => 'source',
					'value' => 'external_link',
				),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Caption', 'appset' ),
				'param_name' => 'caption',
				'description' => __( 'Enter text for image caption.', 'appset' ),
				'dependency' => array(
					'element' => 'source',
					'value' => 'external_link',
				),
			),
			array(
				'type' => 'checkbox',
				'heading' => __( 'Add caption?', 'appset' ),
				'param_name' => 'add_caption',
				'description' => __( 'Add image caption.', 'appset' ),
				'value' => array( __( 'Yes', 'appset' ) => 'yes' ),
				'dependency' => array(
					'element' => 'source',
					'value' => array(
						'media_library',
						'featured_image',
					),
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Image alignment', 'appset' ),
				'param_name' => 'alignment',
				'value' => array(
					__( 'Left', 'appset' ) => 'left',
					__( 'Right', 'appset' ) => 'right',
					__( 'Center', 'appset' ) => 'center',
				),
				'description' => __( 'Select image alignment.', 'appset' ),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Image style', 'appset' ),
				'param_name' => 'style',
				'value' => getVcShared( 'single image styles' ),
				'description' => __( 'Select image display style.', 'appset' ),
				'dependency' => array(
					'element' => 'source',
					'value' => array(
						'media_library',
						'featured_image',
					),
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Image style', 'appset' ),
				'param_name' => 'external_style',
				'value' => getVcShared( 'single image external styles' ),
				'description' => __( 'Select image display style.', 'appset' ),
				'dependency' => array(
					'element' => 'source',
					'value' => 'external_link',
				),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Border color', 'appset' ),
				'param_name' => 'border_color',
				'value' => getVcShared( 'colors' ),
				'std' => 'grey',
				'dependency' => array(
					'element' => 'style',
					'value' => array(
						'vc_box_border',
						'vc_box_border_circle',
						'vc_box_outline',
						'vc_box_outline_circle',
						'vc_box_border_circle_2',
						'vc_box_outline_circle_2',
					),
				),
				'description' => __( 'Border color.', 'appset' ),
				'param_holder_class' => 'vc_colored-dropdown',
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Border color', 'appset' ),
				'param_name' => 'external_border_color',
				'value' => getVcShared( 'colors' ),
				'std' => 'grey',
				'dependency' => array(
					'element' => 'external_style',
					'value' => array(
						'vc_box_border',
						'vc_box_border_circle',
						'vc_box_outline',
						'vc_box_outline_circle',
					),
				),
				'description' => __( 'Border color.', 'appset' ),
				'param_holder_class' => 'vc_colored-dropdown',
			),
			array(
                'type' => 'checkbox',
                'heading' => __( 'Force image to overflow container?', 'appset' ),
                'param_name' => 'max_width',
                'description' => __( 'Checked to force image to overflow container.', 'appset' ),
                'value' => array( __( 'Yes', 'appset' ) => 'yes' ),  
                'admin_label' => true,
            ),
            array(
                'type' => 'checkbox',
                'heading' => __( 'Display image as background image', 'appset' ),
                'param_name' => 'image_as_bg',
                'description' => __( 'Checked to force image to overflow container.', 'appset' ),
                'value' => array( __( 'Yes', 'appset' ) => 'yes' ),  
                'admin_label' => true,
            ),
			array(
				'type' => 'dropdown',
				'heading' => __( 'On click action', 'appset' ),
				'param_name' => 'onclick',
				'value' => array(
					__( 'None', 'appset' ) => '',
					__( 'Link to large image', 'appset' ) => 'img_link_large',
					__( 'Open prettyPhoto', 'appset' ) => 'link_image',
					__( 'Open custom link', 'appset' ) => 'custom_link',
					__( 'Zoom', 'appset' ) => 'zoom',
					__( 'Video', 'appset' ) => 'video',
				),
				'description' => __( 'Select action for click action.', 'appset' ),
				'std' => '',
				'group' => __('On click action', 'appset'),
			),
			array(
				'type' => 'href',
				'heading' => __( 'Video link', 'appset' ),
				'param_name' => 'video_link',
				'value' => 'https://www.youtube.com/embed/SZEflIVnhH8',
				'description' => __( 'Enter URL if you want this image to have a popup video link', 'appset' ),
				'dependency' => array(
					'element' => 'onclick',
					'value' => 'video',
				),
				'group' => __('On click action', 'appset'),
			),
			array(
	             'type' => 'dropdown',
	            'heading' => __( 'Video icon color', 'appset' ),
	            'param_name' => 'icon_class',	            
	            'value' => appset_vc_global_color_options(),
	            'std' => 'preset',
	            'description' => '',
	            'dependency' => array(
					'element' => 'onclick',
					'value' => 'video',
				), 
				'group' => __('On click action', 'appset'),
	        ),
			array(
				'type' => 'href',
				'heading' => __( 'Image link', 'appset' ),
				'param_name' => 'link',
				'description' => __( 'Enter URL if you want this image to have a link (Note: parameters like "mailto:" are also accepted).', 'appset' ),
				'dependency' => array(
					'element' => 'onclick',
					'value' => 'custom_link',
				),
				'group' => __('On click action', 'appset'),
			),
			array(
				'type' => 'dropdown',
				'heading' => __( 'Link Target', 'appset' ),
				'param_name' => 'img_link_target',
				'value' => appset_target_param_list(),
				'dependency' => array(
					'element' => 'onclick',
					'value' => array(
						'custom_link',
						'img_link_large',
					),
				),
				'group' => __('On click action', 'appset'),
			),
			appset_vc_animation_type(),
			array(
				'type' => 'el_id',
				'heading' => __( 'Element ID', 'appset' ),
				'param_name' => 'el_id',
				'description' => sprintf( __( 'Enter element ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'appset' ), 'http://www.w3schools.com/tags/att_global_id.asp' ),
			),
			array(
				'type' => 'textfield',
				'heading' => __( 'Extra class name', 'appset' ),
				'param_name' => 'el_class',
				'value' => '',
				'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'appset' ),
			),
			array(
				'type' => 'css_editor',
				'heading' => __( 'CSS box', 'appset' ),
				'param_name' => 'css',
				'group' => __( 'Design Options', 'appset' ),
			),
			// backward compatibility. since 4.6
			array(
				'type' => 'hidden',
				'param_name' => 'img_link_large',
			),
		),
	);
	
	$newParamData = $args['params'];

 	foreach ( $newParamData as $key => $value ) {
        vc_update_shortcode_param( 'vc_single_image', $value );
    } //$newParamData as $key => $value

    
}
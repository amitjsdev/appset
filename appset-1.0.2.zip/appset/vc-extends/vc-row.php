<?php
function appset_vc_row_type_options(){
    $array = array(
        '' => 'None',
        'hero' => 'Hero row',
        'content' => 'Content row', 
        'reviews' => 'Reviews row',
    );
    $new_arr = array();
    foreach ($array as $key => $value) {
        $new_arr["{$value}"] = $key;
    }
    return $new_arr;
}

function appset_vc_row_class_options(){
    $array = array(
        '' => 'None',
        'content-boxes' => 'Content box',
        'content-txt' => 'Content Text', 
        'hero-txt' => 'Hero Text',
        'hero-img' => 'Hero Image',
        'bg-inner' => 'Inner bg',
        'hero-content' => 'Hero content',
        'section-content' => 'Section content',
    );
    $new_arr = array();
    foreach ($array as $key => $value) {
        $new_arr["{$value}"] = $key;
    }
    return $new_arr;
}

add_action( 'vc_after_init', 'appset_vc_row_settings' );
function appset_vc_row_settings($return = 0) {
    $newParamData = array(
        array(
            'type' => 'el_id',
            'heading' => __( 'Row ID', 'appset' ),
            'param_name' => 'el_id',
            'description' => sprintf( __( 'Enter section ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'appset' ), 'http://www.w3schools.com/tags/att_global_id.asp' ),
            'group' => 'Appset Settings',
            'edit_field_class' => 'vc_col-sm-8',
            'weight' => 123
        ),
        array(
            'type' => 'checkbox',
            'heading' => __( 'Enable outer row container?', 'appset' ),
            'param_name' => 'enable_outer_container',          
            'value' => array( __( 'Checked to enable', 'appset' ) => 'yes' ), 
            'group' => 'Appset Settings',
            'edit_field_class' => 'vc_col-sm-4',
            'weight' => 122
        ),
        array(
            'type' => 'dropdown',
            'heading' => __( 'Row stretch', 'appset' ),
            'param_name' => 'full_width',
            'group' => 'Appset Settings',
            'value' => array(
                __( 'Default', 'appset' ) => '',
                __( 'Stretch row', 'appset' ) => 'stretch_row',
                __( 'Stretch row and content', 'appset' ) => 'stretch_row_content',
                __( 'Stretch row and content (no paddings)', 'appset' ) => 'stretch_row_content_no_spaces',
            ),
            'description' => __( 'Select stretching options for row and content.', 'appset' ),
          
        ),  
        array(
            'type' => 'checkbox',
            'heading' => __( 'Enable inner row container?', 'appset' ),
            'param_name' => 'enable_inner',
            'description' => __( 'Checked to setup section inner bg. You can change image in Design options', 'appset' ),
            'value' => array( __( 'Yes', 'appset' ) => 'yes' ), 
            'group' => 'Appset Settings',
            'dependency' => array(
                'element' => 'full_width',
                'value' => array('stretch_row', 'stretch_row_content')
            )
        ),
        array(
            'group' => 'Appset Settings',
            'type' => 'dropdown',
            'heading' => __( 'Column style', 'appset' ),
            'param_name' => 'column_style',
            'std' => '',
            'edit_field_class' => 'vc_col-sm-6',
            'value' => array(
                 'Default' => '',
                'Border separated' => 'border-separated-column',
                'No spacing in column' => 'no-spacing-column',
            ),
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Predefined row class', 'appset' ),
            'param_name' => 'row_class',
            'group' => 'Appset Settings',
            'value' => appset_vc_row_class_options(),
            'std' => '',
            'description' => '',
            'edit_field_class' => 'vc_col-sm-6',
        ), 
        array(
             'type' => 'dropdown',
            'heading' => __( 'Background', 'appset' ),
            'param_name' => 'inner_bg_class',
            'group' => 'Row inner settings',
            'value' => appset_vc_background_options(),
            'std' => 'bg-tra',
            'description' => '',
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Section inner wide', 'appset' ),
            'param_name' => 'inner_padding_class',
            'group' => 'Row inner settings',
            'value' => appset_vc_padding_options(),
            'description' => __( 'Section top & bottom padding', 'appset' ),  
            'edit_field_class' => 'vc_col-sm-6', 
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )       
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Padding top', 'appset' ),
            'param_name' => 'inner_padding_top',
            'group' => 'Row inner settings',
            'value' => appset_vc_spacing_options('padding', 'top'),
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Padding bottom', 'appset' ),
            'param_name' => 'inner_padding_bottom',
            'group' => 'Row inner settings',
            'value' => appset_vc_spacing_options('padding', 'bottom'),
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )
        ),        
        
        array(
             'type' => 'dropdown',
            'heading' => __( 'Margin top', 'appset' ),
            'param_name' => 'inner_margin_top',
            'group' => 'Row inner settings',
            'value' => appset_vc_spacing_options('margin', 'top'),
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Margin bottom', 'appset' ),
            'param_name' => 'inner_margin_bottom',
            'group' => 'Row inner settings',
            'value' => appset_vc_spacing_options('margin', 'bottom'),
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )
        ), 
        array(
             'type' => 'dropdown',
            'heading' => __( 'Row Background color', 'appset' ),
            'param_name' => 'bg_class',
            'group' => 'Appset Settings',
            'value' => appset_vc_background_options(),
            'std' => 'bg-tra',
            'description' => '',
            'edit_field_class' => 'vc_col-sm-6',
        ),           
        array(
            'type' => 'dropdown',
            'group' => 'Appset Settings',
            'heading' => __( 'Background attachment', 'appset' ),
            'param_name' => 'parallax_image_attachment',
            'std' => 'cover',
            'value' => array(
                 'Default' => 'inherit',
                'Fixed' => 'fixed',
                'Scroll' => 'scroll',
                'Local' => 'local',
                'Unset' => 'inset' 
            ),
            'edit_field_class' => 'vc_col-sm-6',
        ),
        array(
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => __("Custom color", "appset"),
          "param_name" => "custom_bg_color",
          "value" => '',
          'dependency' => array(
                'element' => 'bg_class',
                'value' => array('bg-custom')
            ), 
          "description" => __( "Go to design option to set custom background color. If you are using dark color background use the extra class name to make section text white color", 'appset' ).'  - <small><u>white-color</u></small>',
          'group' => 'Appset Settings',
        ),    
        array(
          "type" => "perch_vc_gradient",
          "title" => __("Gradient background", "appset"),
          "param_name" => "custom_gradient_color",
          'column' => 3,
          "std" => '',
          'settings' => array(
                'fields' => array('direction', 'color1', 'color2')
            ),
          'dependency' => array(
                'element' => 'bg_class',
                'value' => array('bg-custom-gradient')
            ), 
          "description" => __( "Go to design option to set custom background color. If you are using dark color background use the extra class name to make section text white color", 'appset' ).'  - <small><u>white-color</u></small>',
          'group' => 'Appset Settings',
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Padding top', 'appset' ),
            'param_name' => 'padding_top',
            'group' => 'Appset Settings',
            'value' => appset_vc_spacing_options('padding', 'top'),
            'edit_field_class' => 'vc_col-sm-6',  
            'dependency' => array(
                'element' => 'padding_class',
                'value' => array('')
            )          
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Padding bottom', 'appset' ),
            'param_name' => 'padding_bottom',
            'group' => 'Appset Settings',
            'value' => appset_vc_spacing_options('padding', 'bottom'),
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'padding_class',
                'value' => array('')
            )            
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Margin top', 'appset' ),
            'param_name' => 'margin_top',
            'group' => 'Appset Settings',
            'value' => appset_vc_spacing_options('margin', 'top'),
            'edit_field_class' => 'vc_col-sm-6',
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Margin bottom', 'appset' ),
            'param_name' => 'margin_bottom',
            'group' => 'Appset Settings',
            'value' => appset_vc_spacing_options('margin', 'bottom'),
            'edit_field_class' => 'vc_col-sm-6',
        ),
        array(
            'type' => 'dropdown',
            'heading' => __( 'Content position', 'appset' ),
            'param_name' => 'content_placement',
            'value' => array(
                __( 'Default', 'appset' ) => '',
                __( 'Top', 'appset' ) => 'top',
                __( 'Middle', 'appset' ) => 'middle',
                __( 'Bottom', 'appset' ) => 'bottom',
            ),
            'std' => 'middle',
            'description' => __( 'Select content position within columns.', 'appset' ),
            'weight' => 100
        ),
        

         
    );

    if( $return ) return $newParamData;

    foreach ( $newParamData as $key => $value ) {
        vc_update_shortcode_param( 'vc_row', $value );
        vc_update_shortcode_param( 'vc_row_inner', $value );
    } 
    

    $settings = array (
    'show_settings_on_create' => true,
    'category' => __( 'Appset', 'appset' )
    );
    vc_map_update( 'vc_row_inner', $settings );
}


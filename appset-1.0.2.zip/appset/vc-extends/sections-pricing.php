<?php
add_action( 'vc_load_default_templates_action','appset_section_pricing_for_vc' ); // Hook in
function appset_section_pricing_for_vc() {
	$templates = array();
	$templates['Section: Pricing 01'] = '[vc_section section_type="pricing" pricing_type="1" bg_class="bg-tra" parallax_image_attachment="inherit"][vc_row parallax_image_attachment="inherit"][vc_column][perch_section_title title="Simple, Transparent Pricing"][/vc_column][/vc_row][vc_row parallax_image_attachment="inherit"][vc_column width="1/3"][perch_pricing_table align="" title="Freelancer" price="49" color="btn-tra-black"]10 Users Tasks,5 GB in Cloud Storage,10 mySQL Database,9/5 Premium Support[/perch_pricing_table][/vc_column][vc_column width="1/3"][perch_pricing_table align="" price="99" color="btn-green"] 50 Users Tasks, 500 GB in Cloud Storage, 25 mySQL Database, 12/7 Premium Support, [/perch_pricing_table][/vc_column][vc_column width="1/3"][perch_pricing_table align="" title="Corporate" price="159" color="btn-tra-black"] 100 Users Tasks, 100 GB in Cloud Storage, 50 mySQL Database, 24/7 Premium Support, [/perch_pricing_table][/vc_column][/vc_row][/vc_section]';


	
	foreach ($templates as $key => $template) {
		$data               = array(); 
	    $data['name']       = esc_attr($key); // Assign name for your custom template
	    $data['weight']     = 0; 
	    $data['image_path'] = '';
	    $data['custom_class'] = ''; // CSS class name
	    $data['content']    = $template;

	    vc_add_default_templates( $data );
	}
      

}
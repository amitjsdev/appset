<?php
add_filter( 'perch_modules/vc/perch_button_group', 'appset_vc_button_group_default_args' );
function appset_vc_button_group_default_args( $args ){
	$default = array(       
        'subtitle' => '* Requires iOS 7.0 or higher',
        'subtitle_font_container' => 'tag:span|extra_class:os-version',         
    );

    $args = appset_set_default_vc_values($default, $args);   
    
    return $args;    
}
<?php
add_filter( 'perch_modules/vc/perch_feature_box', 'appset_vc_feature_box_default_args' );
function appset_vc_feature_box_default_args( $args ){
	$default = array(
		'icon_tonicons' => 'ti-Line-Key-2',
		'icon_color' => 'grey-color',
		'title' => 'Concrete Security',
		'title_font_container' => 'tag:h5|size:sm',        
        'subtitle' => 'Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor tempus feugiat dolor felis ',
        'subtitle_font_container' => 'tag:p|text_color:grey-color',         
    );

    $args = appset_set_default_vc_values($default, $args);   
    
    return $args;    
}
<?php
function appset_vc_section_type_options(){
    $array = array(
        '' => 'None',
        'hero' => 'Hero section', 
        'features' => 'Features section', 
        'content' => 'Content section', 
        'video' => 'Video section', 
        'reviews' => 'Reviews section', 
        'brands' => 'Brands section', 
        'pricing' => 'Pricing section', 
        'download' => 'Download section', 
        'faqs' => 'Faqs section', 
        'contacts' => 'Contacts section', 
        'footer' => 'Footer section', 
    );
    $new_arr = array();
    foreach ($array as $key => $value) {
        $new_arr["{$value}"] = $key;
    }
    return $new_arr;
}

function appset_vc_section_class_options(){
    $array = array(
        'None' => '',
        'Hero content' => 'hero-content',
    );

    return $array;
}

add_action( 'vc_after_init', 'appset_vc_section_settings' );
function appset_vc_section_settings($return = 0) {

    
    $newParamData = array( 
        array(
            'type' => 'el_id',
            'heading' => __( 'Section ID', 'appset' ),
            'param_name' => 'el_id',
            'description' => sprintf( __( 'Enter section ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'appset' ), 'http://www.w3schools.com/tags/att_global_id.asp' ),
            'group' => 'Appset Settings',
            'edit_field_class' => 'vc_col-sm-8',
            'weight' => 130
        ),  
        array(
            'type' => 'textfield',
            'heading' => __( 'Extra class name', 'appset' ),
            'param_name' => 'el_class',
            'description' => __( 'Use this field to add a class name, refer to it in your css file. E.g: white-color', 'appset' ),
            'group' => 'Appset Settings',
            'weight' => 125,
            'edit_field_class' => 'vc_col-sm-4',
        ),    
        array(
            'group' => 'Appset Settings',
            'type' => 'dropdown',
            'heading' => __( 'Section stretch', 'appset' ),
            'param_name' => 'full_width',
            'weight' => 120,
            'value' => array(
                 __( 'Default', 'appset' ) => 'container',
                __( 'Stretch section', 'appset' ) => 'container-wide' 
            ),
            'description' => __( 'Select stretching options for section and content (Note: stretched may not work properly if parent container has "overflow: hidden" CSS property).', 'appset' ),
            'edit_field_class' => 'vc_col-sm-8',             
        ), 
        array(
            'type' => 'checkbox',
            'param_name' => 'enable_inner',
            'description' => __( 'Checked to setup section inner bg. You can change image in Design options', 'appset' ),
            'value' => array( __( 'Enable section inner', 'appset' ) => 'yes' ), 
            'group' => 'Appset Settings',
            'edit_field_class' => 'vc_col-sm-4',
            'weight' => 119,
        ),       
        array(
            'group' => 'Appset Settings',
            'type' => 'dropdown',
            'weight' => 118,
            'heading' => __( 'Pre-defined Section type', 'appset' ),
            'param_name' => 'section_type',
            'value' => appset_vc_section_type_options(),
            'std' => '',
            'description' => __( 'Predefined section setup section spacing, background image etc.', 'appset' ),
            'edit_field_class' => 'vc_col-sm-8', 
        ),
        appset_vc_section_type_params('hero_type', 'Hero style', 18, 'hero'),        
        appset_vc_section_type_params('features_type', 'Features style', 6, 'features'),        
        appset_vc_section_type_params('content_type', 'Content style', 10, 'content'),        
        appset_vc_section_type_params('video_type', 'Video style', 3, 'video'),        
        appset_vc_section_type_params('reviews_type', 'Reviews style', 3, 'reviews'),        
        appset_vc_section_type_params('brands_type', 'Brands style', 2, 'brands'),        
        appset_vc_section_type_params('pricing_type', 'Pricing style', 2, 'pricing'),        
        appset_vc_section_type_params('download_type', 'Download style', 3, 'download'),        
        appset_vc_section_type_params('faqs_type', 'Faqs style', 1, 'faqs'),        
        appset_vc_section_type_params('contacts_type', 'Contacts style', 6, 'contacts'), 
        appset_vc_section_type_params('footer_type', 'Footer style', 4, 'footer'),
        array(
            'type' => 'el_id',
            'heading' => __( 'Section inner ID', 'appset' ),
            'param_name' => 'inner_el_id',
            'description' => sprintf( __( 'Enter section ID (Note: make sure it is unique and valid according to <a href="%s" target="_blank">w3c specification</a>).', 'appset' ), 'http://www.w3schools.com/tags/att_global_id.asp' ),
            'group' => 'Section inner settings',
            'edit_field_class' => 'vc_col-sm-6', 
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )           
        ),  
        array(
            'type' => 'textfield',
            'heading' => __( 'Extra class for section inner', 'appset' ),
            'param_name' => 'inner_el_class',
            'description' => __( 'Use this field to add a class name, refer to it in your css file. E.g: white-color', 'appset' ),
            'group' => 'Section inner settings',
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )
        ), 
        array(
             'type' => 'dropdown',
            'heading' => __( 'Background', 'appset' ),
            'param_name' => 'inner_bg_class',
            'group' => 'Section inner settings',
            'value' => appset_vc_background_options(),
            'std' => 'bg-tra',
            'description' => '',
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Section inner wide', 'appset' ),
            'param_name' => 'inner_padding_class',
            'group' => 'Section inner settings',
            'value' => appset_vc_padding_options(),
            'description' => __( 'Section top & bottom padding', 'appset' ),  
            'edit_field_class' => 'vc_col-sm-6', 
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )       
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Padding top', 'appset' ),
            'param_name' => 'inner_padding_top',
            'group' => 'Section inner settings',
            'value' => appset_vc_spacing_options('padding', 'top'),
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Padding bottom', 'appset' ),
            'param_name' => 'inner_padding_bottom',
            'group' => 'Section inner settings',
            'value' => appset_vc_spacing_options('padding', 'bottom'),
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )
        ),        
        
        array(
             'type' => 'dropdown',
            'heading' => __( 'Margin top', 'appset' ),
            'param_name' => 'inner_margin_top',
            'group' => 'Section inner settings',
            'value' => appset_vc_spacing_options('margin', 'top'),
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Margin bottom', 'appset' ),
            'param_name' => 'inner_margin_bottom',
            'group' => 'Section inner settings',
            'value' => appset_vc_spacing_options('margin', 'bottom'),
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'enable_inner',
                'value' => 'yes'
            )
        ), 
        array(
             'type' => 'dropdown',
            'heading' => __( 'Section Background', 'appset' ),
            'param_name' => 'bg_class',
            'group' => 'Appset Settings',
            'value' => appset_vc_background_options(),
            'std' => 'bg-white',
            'description' => '',
            'edit_field_class' => 'vc_col-sm-6',
        ),              
        array(
            'type' => 'dropdown',
            'group' => 'Appset Settings',
            'heading' => __( 'Background attachment', 'appset' ),
            'param_name' => 'parallax_image_attachment',
            'std' => 'cover',
            'value' => array(
                 'Default' => 'inherit',
                'Fixed' => 'fixed',
                'Scroll' => 'scroll',
                'Local' => 'local',
                'Unset' => 'inset' 
            ),
            'edit_field_class' => 'vc_col-sm-6',
        ),
        array(
          "type" => "colorpicker",
          "holder" => "div",
          "class" => "",
          "heading" => __("Custom color", "appset"),
          "param_name" => "custom_bg_color",
          "value" => '',
          'dependency' => array(
                'element' => 'bg_class',
                'value' => array('bg-custom')
            ), 
          "description" => __( "Go to design option to set custom background color. If you are using dark color background use the extra class name to make section text white color", 'appset' ).'  - <small><u>white-color</u></small>',
          'group' => 'Appset Settings',
        ),    
        array(
          "type" => "perch_vc_gradient",
          "title" => __("Gradient background", "appset"),
          "param_name" => "custom_gradient_color",
          'column' => 3,
          "std" => '',
          'settings' => array(
                'fields' => array('direction', 'color1', 'color2')
            ),
          'dependency' => array(
                'element' => 'bg_class',
                'value' => array('bg-custom-gradient')
            ), 
          "description" => __( "Go to design option to set custom background color. If you are using dark color background use the extra class name to make section text white color", 'appset' ).'  - <small><u>white-color</u></small>',
          'group' => 'Appset Settings',
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Padding top', 'appset' ),
            'param_name' => 'padding_top',
            'group' => 'Appset Settings',
            'value' => appset_vc_spacing_options('padding', 'top'),
            'edit_field_class' => 'vc_col-sm-6',  
            'dependency' => array(
                'element' => 'padding_class',
                'value' => array('')
            )          
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Padding bottom', 'appset' ),
            'param_name' => 'padding_bottom',
            'group' => 'Appset Settings',
            'value' => appset_vc_spacing_options('padding', 'bottom'),
            'edit_field_class' => 'vc_col-sm-6',
            'dependency' => array(
                'element' => 'padding_class',
                'value' => array('')
            )            
        ),        
        array(
             'type' => 'dropdown',
            'heading' => __( 'Section wide', 'appset' ),
            'param_name' => 'padding_class',
            'group' => 'Appset Settings',
            'value' => appset_vc_padding_options(),
            'std'  => 'wide-60',
            'description' => __( 'Section top & bottom padding', 'appset' ),          
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Margin top', 'appset' ),
            'param_name' => 'margin_top',
            'group' => 'Appset Settings',
            'value' => appset_vc_spacing_options('margin', 'top'),
            'edit_field_class' => 'vc_col-sm-6',
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Margin bottom', 'appset' ),
            'param_name' => 'margin_bottom',
            'group' => 'Appset Settings',
            'value' => appset_vc_spacing_options('margin', 'bottom'),
            'edit_field_class' => 'vc_col-sm-6',
        ),
        array(
            'type' => 'dropdown',
            'heading' => __( 'Parallax', 'appset' ),
            'param_name' => 'parallax',
            'std' => '',
            'weight' => 1,
            'value' => array(
                __( 'None', 'appset' ) => '',
                __( 'Simple', 'appset' ) => 'content-moving',
                __( 'With fade', 'appset' ) => 'content-moving-fade',
            ),
            'description' => __( 'Add parallax type background for section (Note: If no image is specified, parallax will use background image from Design Options).', 'appset' ),
            'dependency' => array(
                'element' => 'video_bg',
                'is_empty' => true,
            ),
        ),       
        array(
             'type' => 'image_upload',
            'heading' => __( 'Image', 'appset' ),
            'param_name' => 'parallax_image',
            'weight' => 119,
            'value' => APPSET_URI . '/images/banner-1.jpg',
            'description' => __( 'Select image from media library.', 'appset' ),
            'dependency' => array(
                 'element' => 'parallax',
                'not_empty' => true 
            ) 
        ),
        array(
            'group' => 'Parallax Settings',
            'type' => 'textfield',
            'heading' => __( 'Parallax background image opacity', 'appset' ),
            'param_name' => 'parallax_image_opacity',
            'value' => '1',      
            'description' => __( 'Maximum value 1', 'appset' ),
            'dependency' => array(
                 'element' => 'parallax',
                'not_empty' => true 
            ),
            'edit_field_class' => 'vc_col-sm-6',  
        ),
        array(
             'group' => 'Parallax Settings',
            'type' => 'dropdown',
            'heading' => __( 'Parallax width', 'appset' ),
            'param_name' => 'parallax_width',
            'std' => '100%',
            'value' => array(
                 '100%' => '100%',
                '75%' => '75%',
                '50%' => '50%',
                '25%' => '25%' 
            ),
            'dependency' => array(
                 'element' => 'parallax',
                'not_empty' => true 
            ),
            'edit_field_class' => 'vc_col-sm-6',  
        ),
        array(
             'group' => 'Parallax Settings',
            'type' => 'dropdown',
            'heading' => __( 'Parallax background image size', 'appset' ),
            'param_name' => 'parallax_image_size',
            'std' => 'cover',
            'value' => array(
                 'Cover' => 'cover',
                'Contain' => 'contain',
                'Auto' => 'auto',
                '25% auto' => '25% auto',
                '50% auto' => '50% auto',
                'auto 50%' => 'auto 50%',
                'auto 25%' => 'auto 25%' 
            ),
            'dependency' => array(
                 'element' => 'parallax',
                'not_empty' => true 
            ) ,
            'edit_field_class' => 'vc_col-sm-6', 
        ),
        array(
             'group' => 'Parallax Settings',
            'type' => 'dropdown',
            'heading' => __( 'Parallax background image repeat', 'appset' ),
            'param_name' => 'parallax_image_repeat',
            'std' => 'cover',
            'value' => array(
                 'Default' => '',
                'No Repeat' => 'no-repeat',
                'Repeat' => 'repeat' 
            ),
            'dependency' => array(
                 'element' => 'parallax',
                'not_empty' => true 
            ) ,
            'edit_field_class' => 'vc_col-sm-6', 
        ),
        array(
             'group' => 'Parallax Settings',
            'type' => 'dropdown',
            'heading' => __( 'Parallax background image position', 'appset' ),
            'param_name' => 'parallax_image_position',
            'std' => 'cover',
            'value' => array(
                 'Default' => '50% 0',
                'Center' => 'center',
                'Top center' => 'top center',
                'Bottom center' => 'bottom center',
                'Top left' => 'top left',
                'Bottom left' => 'bottom left',
                'Top right' => 'top right',
                'Bottom right' => 'bottom right' 
            ),
            'dependency' => array(
                 'element' => 'parallax',
                'not_empty' => true 
            ),
            'edit_field_class' => 'vc_col-sm-6',  
        ),
         
    );

    if( $return ) return $newParamData;

    foreach ( $newParamData as $key => $value ) {
        vc_update_shortcode_param( 'vc_section', $value );
    } //$newParamData as $key => $value 

   

    $settings = array (
        'show_settings_on_create' => true,
      'category' => __( 'Appset', 'appset' )
    );
    vc_map_update( 'vc_section', $settings ); 


}


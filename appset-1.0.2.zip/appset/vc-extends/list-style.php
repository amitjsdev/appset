<?php
add_filter( 'perch_modules/vc/perch_list', 'appset_vc_list_style_default_args' );
function appset_vc_list_style_default_args( $args ){
	$default = array(
		'list_title' => 'Feature Integration',
		'list_title_font_container' => 'tag:h5|size:sm',
    );

    $args = appset_set_default_vc_values($default, $args);   
    
    return $args;    
}
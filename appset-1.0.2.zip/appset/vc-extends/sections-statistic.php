<?php
add_action( 'vc_load_default_templates_action','appset_statistic_sections_for_vc' ); // Hook in
function appset_statistic_sections_for_vc() {
	$templates = array();
	$templates['Section: statistic 2'] = '[vc_section section_type="hero" parallax_image_attachment="fixed" el_id="statistic-2"][vc_row][vc_column width="1/4"][perch_counter_up align="text-center" icon_tonicons="ti-Line-Download-1" counter_color="0" title="Downloads"][/vc_column][vc_column width="1/4"][perch_counter_up align="text-center" icon_tonicons="ti-Line-Paper-plane" prefix="1," count="263" counter_color="0" title="Tickets Closed"][/vc_column][vc_column width="1/4"][perch_counter_up align="text-center" icon_tonicons="ti-Line-People-1" prefix="5," count="172" counter_color="0" title="Followers"][/vc_column][vc_column width="1/4"][perch_counter_up align="text-center" prefix="4," count="874" counter_color="0"][/vc_column][/vc_row][/vc_section]';

	






	
	foreach ($templates as $key => $template) {
		$data               = array(); 
	    $data['name']       = esc_attr($key); // Assign name for your custom template
	    $data['weight']     = 0; 
	    $data['image_path'] = '';
	    $data['custom_class'] = ''; // CSS class name
	    $data['content']    = $template;

	    vc_add_default_templates( $data );
	}
      

}




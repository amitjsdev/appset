<?php
add_action( 'vc_after_init', 'appset_vc_tta_tabs_settings' );
function appset_vc_tta_tabs_settings( ) {
	$value = array(
			'type' => 'dropdown',
			'param_name' => 'style',
			'value' => array(
				'Appset style1' => 'appset',
				'Appset style2' => 'appset-style2',
				__( 'Classic', 'appset' ) => 'classic',
				__( 'Modern', 'appset' ) => 'modern',
				__( 'Flat', 'appset' ) => 'flat',
				__( 'Outline', 'appset' ) => 'outline',
			),
			'heading' => __( 'Style', 'appset' ),
			'description' => __( 'Select tabs display style.', 'appset' ),
		);
	vc_update_shortcode_param( 'vc_tta_tabs', $value );
}
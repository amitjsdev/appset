<header id="<?php appset_header_id(); ?>" <?php appset_header_class('navbar-style2'); ?>>
	<nav <?php appset_navbar_class(); ?>>
		<div class="container">
			<?php
			/**
			 * Hook: appset/header/logo.
			 * Default template file location: appset/header
			 *
			 * @hooked appset_header_logo - 10
			 */
			 do_action( 'appset/header/logo' ); 
			?>

			<?php
			/**
			 * Hook: appset/header/menu.
			 * Default template file location: appset/header
			 *
			 * @hooked appset_header_mobile_menu_icon - 10
			 * @hooked appset_header_nav_menu - 15
			 */
			 do_action( 'appset/header/menu' ); 
			?>

		</div><!-- End container -->
	</nav><!-- End navbar -->
</header><!-- End header -->

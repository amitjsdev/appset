<ul class="navbar-text">	
	<?php echo AppsetHeader::get_navbar_icon_elements(); ?>
</ul><!-- Header Social Icons -->					      	

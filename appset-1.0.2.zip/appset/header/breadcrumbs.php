<?php do_action( 'appset/breadcrumbs/before' ); ?>
<?php if(AppsetHeader::header_banner_is_on()): ?>
	<section id="<?php echo appset_breadcrumbs_id(); ?>" <?php appset_breadcrumbs_class(); ?>>
		<div class="container">	
			<div class="row">
				<div class="col-md-10 offset-md-1">
					<div class="hero-txt text-center">
						<?php do_action( 'appset/breadcrumbs/title/before' ); ?>
						<h2 class="h2-xl"><?php echo AppsetHeader::get_title(); ?></h2><!-- Title -->
						<?php do_action( 'appset/breadcrumbs/title/after' ); ?>
						<p class="p-hero subtitle">
							<?php echo AppsetHeader::get_subtitle(); ?>						
						</p><!-- Text -->	
						<?php do_action( 'appset/breadcrumbs/subtitle/after' ); ?>
					</div><!-- End hero-txt -->
				</div>	<!-- End col-md-10 -->
			</div>	  <!-- End row -->
		</div>	   <!-- End container --> 	
		<div class="parallax-inner"></div>
	</section>	<!-- End breadcrumbs-area -->
<?php endif; ?>
<?php do_action( 'appset/breadcrumbs/after' ); ?>
<?php 
if ( $posts->have_posts() ):  
$info = $posts->info;

?>
<div class="row">
    <?php 
    // Posts are found
    $count = 300;
    while ( $posts->have_posts() ) :
        $posts->the_post();
        global $post;
        ?>
        <div class="col-md-6 col-lg-4">
            <div class="blog-post wow fadeInUp" data-wow-delay="<?php echo intval($count) ?>ms">        
                <?php if( has_post_thumbnail() ): ?>
                    <!-- BLOG POST IMAGE -->
                    <div class="blog-post-img mb-30">
                        <img class="img-fluid" src="<?php the_post_thumbnail_url( esc_attr($info['img_size']) ); ?>" alt="<?php the_title_attribute(); ?>" /> 
                    </div>
                <?php endif; ?>
                
                <div class="blog-post-txt">                    
                    <?php appset_entry_meta(); ?><!-- Post Data -->                    
                    <h5 class="h5-md"><a class="preset-hover" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                    <p><?php echo appset_get_trim_words(get_the_excerpt(), intval($info['excerpt_length']), '...'); ?></p>
                </div><!-- BLOG POST TEXT -->
                <?php
                $read_more_text = appset_get_option( 'read_more_text', 'More Details' );
                $read_more_text = sprintf( _x('%s', 'Read more text', 'appset'), $read_more_text );
                ?>
                <hr>
                <div class="blog-post-meta text-right grey-color">
                    <?php appset_footer_entry_meta(); ?>

                    <a href="<?php the_permalink(); ?>"><?php echo esc_attr($read_more_text); ?></a><!-- Post Link -->
                </div>
            </div>
        </div>

        <?php  
        $count = $count + 100;
    endwhile; 
   ?>   
</div>
<?php 
// Posts not found
else :
    echo '<h4>' . __( 'Posts not found', 'appset' ) . '</h4>';
endif; 






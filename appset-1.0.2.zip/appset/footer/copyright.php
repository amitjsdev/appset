<?php
if( Appset_Footer_Config::copyright_bar_is_on() ):
	$copyright_text = appset_get_option( 'copyright_text', '&copy; ' . date( 'Y' ).' <span>Appset.</span> All Rights Reserved' );
	$copyright_text = sprintf( _x('%s', 'Copyright text', 'appset'), $copyright_text );
	?>
	
	<div class="bottom-footer pt-50 pb-50 mt-0">
		<div class="row">						
			<div class="col-md-12">
				<div class="footer-copyright">
					<p class="mb-0"><?php echo do_shortcode($copyright_text); ?></p>
				</div><!-- END FOOTER COPYRIGHT -->
			</div>
		</div>	
	</div><!-- END FOOTER bottom -->
<?php endif; ?>
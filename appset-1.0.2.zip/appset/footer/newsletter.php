<?php
if( Appset_Footer_Config::newsletter_area_is_on() && !is_page() ):
$newsletter_title = appset_get_option( 'newsletter_title', 'Subscribe to AppSet Update' );	
$newsletter_title = sprintf( _x('%s', 'Newsletter title', 'appset'), $newsletter_title );
$newsletter_placeholder = appset_get_option( 'newsletter_placeholder', 'Your email address' );
$placeholder = sprintf( _x('%s', 'Newsletter placeholder', 'appset'), $newsletter_placeholder );
$sub = 'Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis libero tempus, tempor posuere ligula varius';
$newsletter_subtitle = appset_get_option( 'newsletter_subtitle', $sub );
$newsletter_footer = appset_get_option( 'newsletter_footer', 'We don\'t share your personal information with anyone. Check out our 
						   <a href="#">Privacy Policy</a> for more information' );
?>
<section id="<?php appset_newsletter_id(); ?>" <?php appset_newsletter_class(); ?>>
	<div class="container">
		
		<div class="row">	
			<div class="col-md-12 text-center section-title">
				<h2 class="h2-xs"><?php echo appset_parse_text($newsletter_title); ?></h2><!-- Title 	-->
				<p class="p-lg"><?php echo appset_parse_text($newsletter_subtitle); ?></p><!-- Text -->
			</div>
		</div>	 <!-- END SECTION TITLE -->	
		
		<div class="row">
			<div class="col-md-10 col-lg-8 offset-md-1 offset-lg-2">
				<div class="newsletter-txt text-center">
					<form class="newsletter-form es_shortcode_form"  data-es_form_id="es_shortcode_form">
						<?php 
							if(function_exists('appset_es_subbox')){
								$args = array();
								$group = 'appset';
								$args['placeholder'] = esc_attr($placeholder);
								$args['button_text'] = 'fas fa-arrow-right';
								$args['group'] = esc_attr($group);
								appset_es_subbox( $args );
							}else{
								echo 'Please Install Theme Required & Recommended PLugins.';
							}
							?>
						
						<p class="p-sm"><?php echo do_shortcode($newsletter_footer); ?></p><!-- Small Text -->										
					</form>							
				</div>
			</div>
		</div>	  <!-- END NEWSLETTER FORM -->

	</div>	   <!-- End container -->	
	<div class="parallax-inner"></div>
</section>
<?php 
endif; ?>
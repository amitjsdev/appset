<?php if ( Appset_Footer_Config::widget_area_is_on() ): ?>
<div class="row">
	<?php
	$classArr = array('col-lg-4', 'col-md-4 col-lg-3', 'col-md-3 col-lg-2 offset-md-1 offset-lg-0', 'col-md-4 col-lg-3');
    $total = appset_get_option( 'footer_widget_area_column', '4' );
    for( $i=1; $i<=$total; $i++ ):
        $class = (($total == 4) && function_exists('rwmb_meta'))? $classArr[$i-1] : 'col-md-'.(12/$total);
        $class .= ' pt-100 mb-20';
        $sidebar = 'footer-'.$i;
        if ( is_active_sidebar( $sidebar ) ) :
			?>
			<div class="<?php echo esc_attr($class) ?>">
	            <?php  dynamic_sidebar( $sidebar ); ?>
	        </div>
			<?php 
			endif;
	endfor;
	?>
</div>
<?php endif; ?>

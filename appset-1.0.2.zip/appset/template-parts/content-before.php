<div id="<?php appset_container_id(); ?>" <?php appset_container_class(); ?>>
	<div class="container">
	 	<div class="row">
	 		<!-- BLOG POSTS HOLDER -->
	 		<div class="<?php appset_content_wrap_class(); ?>">
	 			<div class="posts-holder">
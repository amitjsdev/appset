<div id="post-<?php the_ID(); ?>" <?php post_class('wow fadeInUp'); ?>  data-wow-delay="0.1s">
	
	<?php do_action( 'appset_post_format' ); ?>
	
	<div class="blog-post-txt mb-10">
		<?php appset_entry_meta(); ?>
		<h5 class="h5-lg"><?php appset_sticky_post_text(); ?><a href="<?php the_permalink() ?>" class="preset-hover"><?php the_title(); ?></a></h5><!-- Post Title -->
		
		<div class="mb-25 entry-summary">
			<?php the_excerpt(); ?>
		</div><!-- Post Text -->
		
	</div><!-- BLOG POST TEXT -->

	<?php
	wp_link_pages( array(					
		'nextpagelink'     => esc_attr__( 'Next', 'appset'),
	'previouspagelink' => esc_attr__( 'Previous', 'appset' ),
		'pagelink'         => '%',
		'echo'             => 1
	) );

	$read_more_text = appset_get_option( 'read_more_text', 'More Details' );
	$read_more_text = sprintf( _x('%s', 'Read more text', 'appset'), $read_more_text );
	?>
	<hr>
	<div class="blog-post-meta text-right grey-color">
		<?php appset_footer_entry_meta(); ?>

		<a href="<?php the_permalink(); ?>"><?php echo esc_attr($read_more_text); ?></a><!-- Post Link -->
	</div>

</div>	<!-- END BLOG POST #post-<?php the_ID(); ?> -->


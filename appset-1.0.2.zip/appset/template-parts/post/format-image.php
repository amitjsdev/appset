<?php $mbottom = appset_margin_bottom_class_prefix().'20'; ?>
<?php if( has_post_thumbnail() ): ?>			
<div class="blog-post-img <?php echo esc_attr($mbottom); ?>">
	<?php the_post_thumbnail( 'appset-800x400-crop', array('class' => 'img-fluid') ) ?>	
</div><!-- BLOG POST IMAGE -->
<?php endif; ?>
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php do_action( 'appset_post_format' ); ?>
	
	<div class="sblog-post-txt">			
		<?php appset_entry_meta( 'single_post_meta' ); ?><!-- Post Data -->			
		
		<h4 class="h4-md"><?php the_title(); ?></h4><!-- Post Title -->
		<?php appset_social_share(); ?>
		
		<div class="entry-content">
			<?php the_content(); ?>
		</div><!-- Post Text -->
	</div><!-- BLOG POST TEXT -->
</div>	<!-- END BLOG POST #<?php the_ID(); ?> -->

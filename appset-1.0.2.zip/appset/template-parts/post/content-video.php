<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<?php if( has_post_thumbnail() && function_exists('rwmb_get_value') ):
			$field_id = 'oembed'; 
			$video = get_post_meta( get_the_ID(), 'oembed', true );
			$url = rwmb_get_value( $field_id );
			print_r($url);
			?>
		<!-- BLOG POST IMAGE -->
		<div class="blog-post-img m-bottom-20">
			<div class="video-preview text-center mb-10">

				<!-- Change the link HERE!!! -->						
			<a class="video-popup2" href="<?php echo esc_url($video) ?>"> 
				<!-- Play Icon -->									
				<div class="video-btn wow fadeInUp" data-wow-delay="800ms">	
					<div class="video-block-wrapper">
						<div class="video-btn play-icon-<?php echo appset_default_color(); ?>">
							<i class="fas fa-play"></i>
						</div>
					</div>
				</div>
				<!-- Preview Image -->
				<?php the_post_thumbnail( 'appset-800x400-crop', array('class' => 'img-fluid') ) ?>

			</a>								

		</div>
	</div>
	<?php endif; ?>
	
	<div class="blog-post-txt m-bottom-10">			
		<?php appset_entry_meta(); ?>				
		
		<h5 class="h5-lg"><?php appset_sticky_post_text(); ?><a class="preset-hover" href="<?php the_permalink() ?>"><?php the_title(); ?></a></h5><!-- Post Title -->
		
		<div class="m-bottom-25">
			<?php the_excerpt(); ?>
		</div><!-- Post Text -->
	</div>
	<?php
	wp_link_pages( array(					
		'nextpagelink'     => esc_attr__( 'Next', 'appset'),
		'previouspagelink' => esc_attr__( 'Previous', 'appset' ),
		'pagelink'         => '%',
		'echo'             => 1
	) );

	$read_more_text = appset_get_option( 'read_more_text', 'More Details' );
	$read_more_text = sprintf( _x('%s', 'Read more text', 'appset'), $read_more_text );
	?>

	<hr>
	<div class="blog-post-meta text-right grey-color">
		<?php appset_footer_entry_meta(); ?>

		<a href="<?php the_permalink(); ?>"><?php echo esc_attr($read_more_text); ?></a><!-- Post Link -->
	</div>
</div>	<!-- END BLOG POST #post-<?php the_ID(); ?> -->

<?php if( appset_get_page_template_type() == 'default' ): ?>
	<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<div class="page-content"><?php the_content(); ?></div>
	</div>
<?php else: ?>
	<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php the_content(); ?>
	</div>
<?php endif; ?>	

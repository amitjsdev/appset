		</div>	<!-- End #<?php appset_container_id(); ?> (Start in header.php) -->
		<?php 
		/**
		 * Default template location: appset/footer
		 *
		 * @hooked appset_newsletter_form_template_part - 10
		 */
		do_action( 'appset/footer/before' ); 
		?>
		
		<footer id="<?php appset_footer_id(); ?>" <?php appset_footer_class(); ?>>
			<div class="container">

				<?php 
				/**
				 * Default template location: appset/footer
				 *
				 * @hooked appset_footer_widget_area_template_part - 10
				 * @hooked appset_footer_copyright_template_part - 20
				 */
				do_action( 'appset/footer' ); 
				?>				
				

			</div> <!-- End .container -->										
		</footer> <!-- End footer -->

		<?php 
		/**
		 * Default template location: appset/footer
		 *
		 * @hooked appset_quick_contact_form_template_part - 10
		 */
		do_action( 'appset/footer/after' ); 
		?>
		
	</div>	<!-- End #<?php appset_wrapper_id(); ?> (Start in header.php) -->

<?php wp_footer(); ?>

</body>
</html>

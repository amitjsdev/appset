<?php
// Register Style
function appset_iconpicker_styles() {
    wp_register_style( 'fontawesome', APPSET_URI. '/admin/iconpicker/icon-fonts/fontawesome-5.2.0/css/fontawesome.min.css', false, '5.0.0', 'all' );    
    wp_register_style( 'flaticon', APPSET_URI. '/css/flaticon.css', false, '1.0' );
    wp_register_style( 'tonicons', APPSET_URI. '/css/tonicons.css', false, '1.0' );
}

// Hook into the 'admin_enqueue_scripts' action
add_action( 'init', 'appset_iconpicker_styles' );


// Register Style
function appset_admin_styles( ) {
    wp_enqueue_style( 'appset-admin-style', APPSET_URI . '/admin/assets/css/style.css', false, '1.0.0', 'all' );
    wp_enqueue_style( 'appset-vc-admin', APPSET_URI . '/admin/assets/css/vc-admin.css', false, '1.0.0', 'all' );   
    wp_enqueue_style( 'tonicons' );
	wp_enqueue_style( 'fontawesome' );

}
// Hook into the 'admin_enqueue_scripts' action
add_action( 'admin_enqueue_scripts', 'appset_admin_styles' );
// Register Script
function appset_admin_scripts( ) {
    wp_enqueue_media();
    wp_enqueue_script( 'v4-shims', APPSET_URI .'/js/fa-v4-shims.min.js', array( 'jquery' ), '1.0.0', true );
   
    wp_register_script( 'appset-scripts', APPSET_URI . '/admin/assets/js/scripts.js', array(
         'jquery' 
    ), '1.0.0.8', false );
    wp_enqueue_script( 'appset-scripts' );

    $arr = array( 
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'APPSET_URI' => APPSET_URI,
        'APPSET_DIR' => APPSET_DIR,
        'animation' => appset_get_option( 'appset_animation', 'on' ),
        'vc_preview' => appset_get_option('vc_admin_view', 'full')
        );
    wp_localize_script( 'appset-scripts', 'APPSET', $arr );
}
// Hook into the 'admin_enqueue_scripts' action
add_action( 'admin_enqueue_scripts', 'appset_admin_scripts' );

function appset_admin_editor_dynamic_css() {    
    wp_add_inline_style( 'appset-admin-bootstrap', appset_dynamic_general_style_css() );  
}
add_action( 'admin_enqueue_scripts', 'appset_admin_editor_dynamic_css' );
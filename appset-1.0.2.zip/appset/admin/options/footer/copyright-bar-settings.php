<?php
function appset_copyright_bar_options( $metabox = false, $options = array() ){
    $options = array(
        array(
             'id' => 'footer_copyright_bar',
            'title' =>  __( 'Footer copyright', 'appset' ),
            'desc' => '',
            'default' => true,
            'type' => 'switch',          
        ), 
        array(
             'id' => 'copyright_text',
            'title' => __( 'Copyright Text', 'appset' ),
            'desc' => '',
            'default' => '&copy; ' . date( 'Y' ).' <span>Appset.</span> All Rights Reserved',
            'type' => 'editor',
            'args' => array('media_buttons' => false, 'teeny' => true, 'textarea_rows' => 2, 'wpautop' => false),
            'required' => array('footer_copyright_bar', '=', true),
        ),         
        
    );

    if($metabox){
        return apply_filters( 'appset/redux_to_metaboxes', $options);
    }else{
        return $options;
    }
}
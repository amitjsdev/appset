<?php
function appset_widget_area_options( $metabox = false, $options = array() ){
	$options = array(
        array(
             'id' => 'footer_widget_area',
            'title' => __( 'Footer widget area Display','appset' ),
            'desc' => '',
            'default' => true,
            'type' => 'switch',          
        ), 
        array(
            'id'            => 'footer_widget_area_column',
            'type'          => 'slider',
            'title'         => __( 'Footer widget area column', 'appset' ),
            'desc'          => __( 'Min: 1, max: 4, step: 1, default value: 4', 'appset' ),
            'default'       => 4,
            'min'           => 1,
            'step'          => 1,
            'max'           => 4,
            'resolution'    => 1,
            'display_value' => 'text',
            'required' => array('footer_widget_area','equals',true)
        ),          
        
	);
	

    if($metabox){
        return apply_filters( 'appset/redux_to_metaboxes', $options);
    }else{
        return $options;
    }
}
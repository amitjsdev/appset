<?php
function appset_footer_newsletter_options( $metabox = false ){
    $options = array(        
        array(
             'id' => 'newsletter_area',
            'title' => __( 'Newsletter area Display', 'appset' ),
            'desc' => 'Display before footer area',
            'default' => false,
            'type' => 'switch',          
        ),
        array(
             'id' => 'newsletter_title',
            'title' => __( 'Newsletter title', 'appset' ),
            'desc' => 'Use {} to highlight text',
            'default' => __( 'Subscribe to AppSet Update', 'appset' ),
            'type' => 'text',
            'required' => array('newsletter_area', '=', true),
        ),
        array(
             'id' => 'newsletter_subtitle',
            'title' => __( 'Newsletter subtitle', 'appset' ),
            'desc' => 'Use {} to highlight text',
            'default' => 'Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis libero tempus, tempor posuere ligula varius',
            'type' => 'textarea',
            'args' => array('media_buttons' => false, 'wpautop' => false),
            'required' => array('newsletter_area', '=', true),
        ),
        array(
             'id' => 'newsletter_placeholder',
            'title' => __( 'Newsletter email placeholder', 'appset' ),
            'desc' => '',
            'default' =>  __( 'Your email address', 'appset' ),
            'type' => 'text',
            'required' => array('newsletter_area', '=', true),
        ),
        array(
             'id' => 'newsletter_footer',
            'title' => __( 'Newsletter footer text', 'appset' ),
            'desc' => '',
            'default' => 'We don\'t share your personal information with anyone. Check out our <a href="#">Privacy Policy</a> for more information',
            'type' => 'editor',
            'args' => array('media_buttons' => false),
            'required' => array('newsletter_area', '=', true),
        )
    );

    $bg_color = array(
        array(
            'id' => 'newsletter_bg_class',
            'title' => __( 'Newsletter background color', 'appset' ),
            'desc' => '',
            'default' => 'bg-lightgrey',
            'type' => 'select',            
            'prefix' => 'newsletter_bg',
            'selector' => '.newsletter-section',            
            'options' => appset_redux_options(appset_bg_color_options()),
            'required' => array('newsletter_area', '=', true),         
        )
    );
    $bg_color = apply_filters( 'appset/bg-color', $bg_color );
    $options = array_merge( $options, $bg_color);

    $options = array_merge( $options, array(
        array(
            'id'       => 'newsletter_parallax_switch',
            'type'     => 'switch', 
            'title'    => __('Newsletter background parallax', 'appset'),            
            'default'  => false,
            'required' => array('newsletter_area', '=', true)
        ),        
        array(
            'id'       => 'newsletter_bg',
            'type'     => 'background',
            'output'   => array( '.newsletter-section .parallax-inner' ),
            'title'    => __( 'Newsletter parallax background', 'appset' ),
            'subtitle' => __( 'Newsletter background with image, color, etc.', 'appset' ),
            'preview' => true,
            'preview_media' => false,
            'background-clip' => true,
            'background-origin' => true,
            'background-color' => false,
            'preview_height' => '200px',
            'default'  => array( 'background-size' => 'cover',),
            'required' => array('newsletter_parallax_switch', '=', true)
        ),
        array(
            'id'            => 'newsletter_parallax_opacity',
            'type'          => 'slider',
            'title'         => __( 'Newsletter parallax opacity', 'appset' ),
            'desc'          => __( 'Min: 0, max: 1, step: .1, default value: 1', 'appset' ),
            'default'       => 1,
            'min'           => 0,
            'step'          => .1,
            'max'           => 1,
            'resolution'    => 0.1,
            'display_value' => 'text',
            'required' => array('newsletter_parallax_switch','equals',true)
        ),
    ));

	

    if($metabox){
        return apply_filters( 'appset/redux_to_metaboxes', $options);
    }else{
        return $options;
    }
}
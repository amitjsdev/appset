<?php
function appset_styling_options( $options = array( ) ) {
    $options = array(
         array(
             'id' => 'primary_color',
            'label' => __( 'Preset color', 'appset' ),
            'desc' => '',
            'std' => apply_filters( 'appset_primary_color_default', '#48af4b'),
            'type' => 'colorpicker',
            'section' => 'styling_options',
            'operator' => 'and' 
        ),
        array(
             'id' => 'primary_color_2',
            'label' => __( 'Preset color dark', 'appset' ),
            'desc' => '',
            'std' => apply_filters( 'appset_primary_color_2_default', '#469248'),
            'type' => 'colorpicker',
            'section' => 'styling_options',
            'operator' => 'and' 
        ),
        array(
             'id' => 'secondary_color',
            'label' => __( 'Dark color', 'appset' ),
            'desc' => '',
            'std' => apply_filters( 'appset_dark_color_default', '#222'),
            'type' => 'colorpicker',
            'section' => 'styling_options',
            'operator' => 'and' 
        ),
        array(
             'id' => 'white_color_alt',
            'label' => __( 'Grey color', 'appset' ),
            'desc' => '',
            'std' => apply_filters( 'appset_grey_color_default', '#f0f0f0'),
            'type' => 'colorpicker',
            'section' => 'styling_options',
            'operator' => 'and' 
        ) 
    );
    return apply_filters( 'appset_theme_options', $options, 'styling_options' );
}
?>
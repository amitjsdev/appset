<?php
function appset_blog_options( $options = array( ) ) {
    $options = array(        
        array(
             'id' => 'blog_layout',
            'label' => __( 'Blog layout', 'appset' ),
            'desc' => 'Optional. Only work, When Posts page is not selected in Settings > Reading.',
            'std' => 'rs',
            'type' => 'radio-image',
            'section' => 'blog_options',
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'min_max_step' => '',
            'class' => '',
            'condition' => '',
            'operator' => 'and',
            'choices' => array(
                 array(
                     'value' => 'full',
                    'label' => __( 'Full width', 'appset' ),
                    'src' => APPSET_URI . '/admin/assets/images/layout/full-width.png' 
                ),
                array(
                     'value' => 'ls',
                    'label' => __( 'Left sidebar', 'appset' ),
                    'src' => APPSET_URI . '/admin/assets/images/layout/left-sidebar.png' 
                ),
                array(
                     'value' => 'rs',
                    'label' => __( 'Right sidebar', 'appset' ),
                    'src' => APPSET_URI . '/admin/assets/images/layout/right-sidebar.png' 
                ) 
            ) 
        ),
        array(
             'id' => 'blog_layout_sidebar',
            'label' => __( 'Blog Sidebar', 'appset' ),
            'desc' => '',
            'std' => 'sidebar-post',
            'type' => 'sidebar-select',
            'section' => 'blog_options',
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'min_max_step' => '',
            'class' => '',
            'condition' => 'blog_layout:not(full)',
            'operator' => 'and' 
        ),
         array(
             'id' => 'sticky_post_text',
            'label' => __( 'Sticky post text', 'appset' ),
            'desc' => '',
            'std' => 'Sticky',
            'type' => 'text',
            'section' => 'blog_options',
            'condition' => '',
            'operator' => 'and' 
        ),
         array(
             'id' => 'post_meta_display',
            'label' => __( 'Post meta display', 'appset' ),
            'desc' => '',
            'std' => 'on',
            'type' => 'on-off',
            'section' => 'blog_options' 
        ),
        /*array(
            'id'          => 'post_meta',
            'label'       => __( 'Post meta options', 'appset' ),
            'std'         => array('date', 'category'),
            'type'        => 'checkbox',
            'section'     => 'blog_options',
            'condition'   => 'post_meta_display:is(on)',
            'operator'    => 'and',
            'choices'     => array(                 
              array(
                'value'       => 'date',
                'label'       => __( 'Post date', 'appset' ),
              ),
              array(
                'value'       => 'category',
                'label'       => __( 'Post category', 'appset' ),
              ),
              array(
                'value'       => 'author',
                'label'       => __( 'Post author', 'appset' ),
              ),
              array(
                'value'       => 'comment',
                'label'       => __( 'Post comments', 'appset' ),
              )
            )
        ),*/
        array(
             'id' => 'excerpt_length',
            'label' => __( 'Excerpt Length', 'appset' ),
            'desc' => '',
            'std' => '40',
            'type' => 'text',
            'section' => 'blog_options',
            'min_max_step' => '1,150,1',
            'condition' => '',
            'operator' => 'and' 
        ),
        array(
             'id' => 'read_more_text',
            'label' => __( 'Read more text', 'appset' ),
            'desc' => '',
            'std' => 'More Details',
            'type' => 'text',
            'section' => 'blog_options',
            'rows' => '',
            'post_type' => '',
            'taxonomy' => '',
            'min_max_step' => '',
            'class' => '',
            'condition' => '',
            'operator' => 'and' 
        ),
        array(
             'id' => 'next_post_text',
            'label' => __( 'Next post text', 'appset' ),
            'desc' => '',
            'std' => 'Next',
            'type' => 'text',
            'section' => 'blog_options' 
        ),
        array(
             'id' => 'prev_post_text',
            'label' => __( 'Previous post text', 'appset' ),
            'desc' => '',
            'std' => 'Previous',
            'type' => 'text',
            'section' => 'blog_options' 
        ),
        
    );
    return apply_filters( 'appset_theme_options', $options, 'blog_options' );
}

foreach ( glob( APPSET_DIR . "/admin/options/blog/*-settings.php" ) as $filename ) {
    if( file_exists($filename) ){
        load_template($filename);
    }    
}
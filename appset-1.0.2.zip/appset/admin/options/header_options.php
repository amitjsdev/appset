<?php
function appset_woo_cart_icon_option( ) {
    if ( function_exists( 'is_woocommerce' ) ) {
        return array(
             'id' => 'header_cart_icon',
            'label' => __( 'Header cart icon display', 'appset' ),
            'desc' => '',
            'std' => 'off',
            'type' => 'on-off',
            'section' => 'header_options',
            'condition' => '',
            'operator' => 'or' 
        );
    } //function_exists( 'is_woocommerce' )
}
function appset_langs_dropdown_option( ) {
    return array(
         'id' => 'header_language_dropdown',
        'label' => __( 'Header topbar Language dropdown display', 'appset' ),
        'desc' => 'This option only applicable when <strong>WPML</strong>, <strong>Polylang</strong> or <strong>Multilanguage by BestWebSoft</strong> plugins are installed',
        'std' => 'on',
        'type' => 'on-off',
        'section' => 'header_options',
        'condition' => '',
        'operator' => 'or' 
    );
}
function appset_header_options( $metabox = false ) {
    $options = array(
        array(
            'id'       => 'logo_type',
            'type'     => 'button_set',
            'title'    => __( 'Logo type', 'appset' ), 
            'subtitle'    => __('Choose your site logo', 'appset'),          
            'options'  => array(
                'image' => 'Image',
                'text' => 'Text',
            ),
            'default'  => 'image'
        ),
        array(
            'id'       => 'logo',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Logo', 'appset' ),
            'compiler' => 'true',
            //'mode'      => false, // Can be set to false to allow any media type, or can also be set to any mime type.
            'desc'     => '',
            'subtitle' => __( 'Upload any media using the WordPress native uploader', 'appset' ),
            'default'  => array( 'url' => apply_filters( 'appset_header_logo_default', APPSET_URI . '/images/logo.png') ),
            'hint'      => array(
                'content'   => __('Display on light color navbar background', 'appset'),
            ),
            'required' => array('logo_type','equals','image')
        ), 
        array(
            'id'       => 'logo_white',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Logo white', 'appset' ),
            'compiler' => 'true',
            //'mode'      => false, // Can be set to false to allow any media type, or can also be set to any mime type.
            'desc'     => '',
            'subtitle' => __( 'Upload any media using the WordPress native uploader', 'appset' ),
            'default'  => array( 'url' => apply_filters( 'appset_header_logo_default', APPSET_URI . '/images/logo-white.png') ),
            'hint'      => array(
                'content'   => __('Display on dark type navbar background', 'appset'),
            ),
            'required' => array('logo_type','equals','image')
        ), 
        array(
            'id'             => 'logo_dimensions',
            'type'           => 'dimensions',
            'units'          => array( 'px' ),    // You can specify a unit value. Possible: px, em, %
            'units_extended' => false,  // Allow users to select any type of unit
            'title'          => __( 'Logo Dimensions (Width/Height)', 'appset' ),
            'subtitle'       => __( 'Choose width, height', 'appset' ),
            'default'        => array(
                'width'  => 125,
                'height' => 30,
            ),
            'required' => array('logo_type','equals','image')
        ),
        array(
            'id'    => 'logo_text',
            'type'  => 'text',
            'title' => 'Logo',
            'default' => get_bloginfo( 'name' ),
            'required' => array('logo_type','equals','text')
        ),   
        /*array(        
        'id' => 'header_menu_breakpoint',        
        'label' => __( 'Header menu breakpoint', 'appset' ),        
        'desc' => 'in pixel',        
        'std' => '800',        
        'type' => 'text',
        'section' => 'header_options'         
        ),*/
        //appset_langs_dropdown_option(),
        //appset_woo_cart_icon_option(),         
    );
    if($metabox){
        return apply_filters( 'appset/redux_to_metaboxes', $options);
    }else{
        return $options;
    }
    
}


foreach ( glob( APPSET_DIR . "/admin/options/header/*-settings.php" ) as $filename ) {
    if( file_exists($filename) ){
        load_template($filename);
    }    
}
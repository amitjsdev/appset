<?php
function appset_general_options( $options = array() ) {
    $_options = array(
        array(
            'id'       => 'appset_layout_style',
            'type'     => 'button_set',
            'title'    => __( 'Global layout design', 'appset' ), 
            'desc'    => __('Globally effect on theme buttons, form elements etc', 'appset'),          
            'options'  => array(
                'rounded' => 'Rounded',
                'semirounded' => 'Semi-rounded',
                'flat' => 'Flat'
            ),
            'default'  => 'semirounded'
        ),
        array(
            'id'       => 'preloader_display',
            'type'     => 'button_set',
            'title'    => __( 'Preloader display', 'appset' ),           
            'options'  => array(
                'none' => 'None',
                'default' => 'Default preloader',
                'custom' => 'Custom preloader'
            ),
            'default'  => 'default'
        ),
        
    );
    $options = array(                   
        array(
             'id' => 'custom_preloader',
            'label' => __( 'Custom preloader image', 'appset' ),
            'desc' => '',
            'std' => APPSET_URI . '/images/preloader.png',
            'type' => 'upload',
            'section' => 'general_options',
            'condition' => 'preloader_display:is(custom)',
            'operator' => 'and' 
        ),                      
        array(
             'id' => 'google_map_api',
            'label' => __( 'Google map API', 'appset' ),
            'desc' => 'Authentication for the standard API - API keys. <br><a class="button" href="//console.developers.google.com/flows/enableapi?apiid=maps_backend,geocoding_backend,directions_backend,distance_matrix_backend,elevation_backend&keyType=CLIENT_SIDE&reusekey=true" target="_blank"><strong>Get an API key</strong></a>',
            'std' => '',
            'type' => 'text',
            'section' => 'general_options',
            'condition' => '',
            'operator' => 'and' 
        ),
        array(
            'id'       => 'social_links',
            'type'     => 'select',
            'multi'    => true,
            'title'    => __('Social Links', 'appset'),            
            'desc'     => sprintf(__('You can set up your social settings <a target="_blank" href="%s">here</a>', 'appset'), admin_url( 'admin.php?page=appset-settings#tab-social_settings' )),           
            'options'  => appset_supported_social_links_callback(),
            'default'  => appset_general_options_social_link(),            
        ),
        array(
             'id' => 'search_placeholder',
            'label' => __( 'Search Placeholder Text', 'appset' ),
            'desc' => '',
            'std' => 'Search...',
            'type' => 'text',
            'section' => 'general_options',
            'condition' => '',
            'operator' => 'and' 
        ),      
        
    );
    $options =  apply_filters( 'appset_theme_options', $options, 'general_options' );

    return array_merge($_options, $options);
}

function appset_general_advanced_options(){

    $options = array( 
        array(
             'id' => 'admin_logo',
            'label' => __( 'Admin logo', 'appset' ),
            'desc' => '',
            'std' => APPSET_URI . '/images/logo.png',
            'type' => 'upload',
            'section' => 'general_options',
            'condition' => '',
            'operator' => 'and' 
        ), 
        array(
            'id'          => 'vc_admin_view',
            'label'       => __( 'Visual composer element preview', 'appset' ),
            'desc'        => __('Only worked in VC admin page edit', 'appset'),
            'std'         => 'full',
            'type'        => 'select',
            'section'     => 'general_options',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and',
            'choices'   => array(
                array(
                    'label' => 'Full preview',
                    'value' => 'full' 
                    ),
                array(
                    'label' => 'Simple preview',
                    'value' => 'simple' 
                    ),
                )
        ),
        
    );

    return  apply_filters( 'appset_theme_options', $options, 'general_options' );

}
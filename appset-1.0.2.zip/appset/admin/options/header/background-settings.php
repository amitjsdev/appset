<?php
function appset_header_background_options( $args = array( ) ) {   

    $options = array(  
        array(
            'id'       => 'title_display',
            'type'     => 'switch', 
            'title'    => __('Header breadcrumbs display', 'appset'),            
            'default'  => true,
        ),         
        array(
            'id'       => 'header_bg_style',
            'type'     => 'button_set',
            'title'    => __( 'Header background type', 'appset' ),
            'subtitle'    => __('Choose your site header background type', 'appset'),          
            'options'  => array(
                '' => 'Inherit',
                'solid' => 'Solid/Gradient color',
            ),
            'default'  => 'solid'
        ),       
    );

    $bg_color = array(
        array(
            'id' => 'header_bg_class',
            'title' => __( 'Header background color', 'appset' ),
            'desc' => '',
            'default' => 'bg-light',
            'type' => 'select',            
            'prefix' => 'header_bg',
            'selector' => '#breadcrumbs-hero',            
            'options' => appset_redux_options(appset_bg_color_options()),
            'required' => array( 
                array('header_bg_style','!=',''),
            )           
        )
    );
    $bg_color = apply_filters( 'appset/bg-color', $bg_color );

    $options = array_merge( $options, $bg_color);
    $options = array_merge( $options, array( 
        array(
            'id'       => 'header_parallax_switch',
            'type'     => 'switch', 
            'title'    => __('Header background parallax', 'appset'),            
            'default'  => false,
        ),
        array(
            'id'       => 'header_parallax_bg',
            'type'     => 'background',
            'output'   => array( '#breadcrumbs-hero .parallax-inner' ),
            'title'    => __( 'Header parallax background', 'appset' ),
            'subtitle' => __( 'Header background with image, color, etc.', 'appset' ),
            'preview' => true,
            'preview_media' => false,
            'background-clip' => true,
            'background-origin' => true,
            'background-color' => false,
            'preview_height' => '200px',
            'default'  => array(
                'background-size' => 'cover',
            ),
            'required' => array('header_parallax_switch','equals',true)
        ),
        array(
            'id'            => 'header_parallax_opacity',
            'type'          => 'slider',
            'title'         => __( 'Header parallax opacity', 'appset' ),
            'desc'          => __( 'Min: 0, max: 1, step: .1, default value: 1', 'appset' ),
            'default'       => 1,
            'min'           => 0,
            'step'          => .1,
            'max'           => 1,
            'resolution'    => 0.1,
            'display_value' => 'text',
            'required' => array('header_parallax_switch','equals',true)
        ),
               
    ));
    return $options;
}
<?php
function appset_header_navbar_icons_options( $metabox = false, $args = array( ) ) {
	  

    $options =  array( 
        array(
             'id' => 'header_search_display',
            'title' => __( 'Navbar Search icon display', 'appset' ),
            'desc' => '',
            'default' => false,
            'type' => 'switch',          
        ),
        array(
             'id' => 'nav_search_placeholder',
            'title' => __( 'Navbar Search placeholder text', 'appset' ),
            'desc' => '',
            'default' => 'What are you looking for?',
            'type' => 'text',
            'required' => array('header_search_display', '=', true),
        ),
        array(
             'id' => 'header_social_icons_display',
            'title' => __( 'Social Icons display', 'appset' ),
            'desc' => '',
            'default' => false,
            'type' => 'switch',          
        ),
        array(
            'id'       => 'header_social_icons',
            'type'     => 'select',
            'multi'    => true,
            'title'    => __('Social Icons', 'appset'),            
            'desc'     => sprintf(__('You can set up your social settings <a target="_blank" href="%s">here</a>', 'appset'), admin_url( 'admin.php?page=appset-settings#tab-social_settings' )),           
            'options'  => appset_supported_social_links_callback(),
            'default'  => array('facebook','twitter'),
            'required' => array('header_social_icons_display', '=', true),
        ),
        array(
             'id' => 'header_button_display',
            'title' => __( 'Header button display', 'appset' ),
            'desc' => '',
            'default' => false,
            'type' => 'switch',          
        ),
        array(
            'id'       => 'header_buttons',
            'type'     => 'select',
            'multi'    => true,
            'title'    => __('Header buttons', 'appset'),            
            'desc'     => sprintf(__('You can set up your button settings <a target="_blank" href="%s">here</a>', 'appset'), admin_url( 'admin.php?page=appset-settings#tab-button_settings' )),           
            'options'  => appset_supported_buttons_callback(),
            'default'  => array('contact_us'),
            'required' => array('header_button_display', '=', true),
        ),
    );    


    if($metabox){
        return apply_filters( 'appset/redux_to_metaboxes', $options);
    }else{
        return $options;
    }
}
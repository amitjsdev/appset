<?php
defined( 'ABSPATH' ) || exit;
/**
* Appset config
*/
class Appset_Header_Config extends Appset{

	function __construct(){	
		add_filter('appset_wrapper_class', array( $this, 'predefined_wrapper_class' ), 10, 2 );		
	}

	/*
	* predefined_layout class
	* @return array
	*/
	public static function predefined_wrapper_class($classes, $class){	
		if(AppsetHeader::header_banner_is_on()){
			$classes[] = 'header-banner-on';
		}
		
		return $classes;
	}

	/*
	* Get logo type
	* @return    string
	*/
	public static function logo_type(){
		$opt_name = 'logo_type';
		$default = 'image';

		$output = appset_get_option( $opt_name, $default );
		$output = apply_filters( 'appset/logo_type', $output );

		return $output;
	}	

	/*
	* logo text
	* @param     string
	* @return    html
	*/
	private static function logo_text( $text = '' ){
		if( $text == '' ) return '';

		return $text;
	}

	/*
	* logo
	* @param     boolean
	* @return    url
	*/
	public static function logo( $dark ){
		$logo_type = self::logo_type();		
		$opt_name = ( $dark )? 'logo_white' : 'logo';
		$default = ( $dark )? APPSET_URI.'/images/logo-white.png' : APPSET_URI.'/images/logo.png';
		
		// image logo
		if( $logo_type == 'image' ):
			$logo = appset_get_option( $opt_name );			
			$output = isset($logo[ 'url' ])? $logo[ 'url' ] : $default;		
		endif;

		// text logo
		$opt_name = 'logo_text';
		if( $logo_type == 'text' ):
			$logo = appset_get_option( $opt_name, get_bloginfo( 'name' ));

			//Generate logo html
			//$logo = self::logo_text($logo);
			$output = $logo;		
		endif;

		$output = apply_filters( 'appset/get_logo', $output, $logo_type, $dark );

		return $output;
	}	

	/*
	* logo type
	* @return string
	*/
	public static function get_logo_type(){
		return self::logo_type();
	}

	/*
	* logo type
	* @param boolean
	* @return Url
	*/
	public static function get_logo($dark = true){
		return self::logo($dark);
	}

	/*
	* navbar_style
	* @return    string
	*/
	private static function navbar_style(){
		$opt_name = 'navbar_style';
		$default = 'style1';

		$output = appset_get_option( $opt_name, $default );
		$output = apply_filters( 'appset/navbar_style', $output );
		return $output;
	}

	/*
	* Navbar style
	* @return string
	*/
	public static function get_navbar_style(){
		return self::navbar_style();
	}

	/*
	* Social Icons display
	* @return Boolean
	*/
	public static function header_search_icon_is_on(){
		$opt_name = 'header_search_display';
		$default = false;

		$output = appset_get_option( $opt_name, $default );
		$output = apply_filters( 'appset/header_search_display', $output );
		return $output;
	}

	/*
	* Social Icons display
	* @return Boolean
	*/
	public static function header_social_icons_is_on(){
		$opt_name = 'header_social_icons_display';
		$default = false;

		$output = appset_get_option( $opt_name, $default );
		$output = apply_filters( 'appset/header_social_icons_display', $output );
		return $output;
	}

	/*
	* Social Icons
	* @return array
	*/
	public static function header_social_icons(){
		$opt_name = 'header_social_icons';
		$default = array('facebook','twitter');

		$output = appset_get_option( $opt_name, $default );
		$output = apply_filters( 'appset/header_social_icons', $output );
		return $output;
	}

	/*
	* Social Icons
	* @return array()
	*/
	public static function _header_social_icons(){
		if(self::header_social_icons_is_on()){
			return self::header_social_icons();
		}else{
			return array();
		}		
	}

	/*
	* Social Icons html
	* @return array()
	*/
	public static function get_header_social_icons($args = array(), $output = ''){		
		$iconsArr = self::_header_social_icons();		
		if(empty($iconsArr)) return $output;
		
		$icon_list = appset_default_social_links_callback();	
		$options = get_option('appset_settings', array());
		if( !empty($options) ):			
		$icon_list = $options['social_links_group'];		
		endif;

		$iconsArr = array_filter($iconsArr);
		$array = array();
		if( !empty($iconsArr) ):			
			foreach ($iconsArr as $key => $value) {
				$array[] = isset($icon_list[$value])? $icon_list[$value] : array();
			}
		endif;
		$array = array_filter($array);

		$output = self::get_social_icons_html($array, $args);

		return $output;
	}

	/*
	* Buttons display
	* @return Boolean
	*/
	public static function header_buttons_is_on(){
		$opt_name = 'header_button_display';
		$default = false;

		$output = appset_get_option( $opt_name, $default );

		$output = apply_filters( 'appset/header_button_display', $output );

		return $output;
	}

	/*
	* Buttons
	* @return array
	*/
	public static function header_buttons(){
		$opt_name = 'header_buttons';
		$default = array('contact_us');

		$output = appset_get_option( $opt_name, $default );
		$output = apply_filters( 'appset/header_buttons', $output );		
		return $output;
	}

	/*
	* Buttons
	* @return array()
	*/
	public static function _header_buttons(){
		if(self::header_buttons_is_on()){
			return self::header_buttons();
		}else{
			return array();
		}		
	}

	/*
	* Buttons html
	* @return array()
	*/
	public static function get_header_buttons($args = array(), $output = ''){		
		
		$iconsArr = self::_header_buttons();
		if(empty($iconsArr)) return $output;

		$_array = appset_default_buttons_set_callback();	
		$options = get_option('appset_settings', array());
		if( !empty($options) ):			
		$_array = $options['buttons_group'];		
		endif;

		$iconsArr = array_filter($iconsArr);

		
		$array = array();
		foreach ($iconsArr as $key => $value) {
			$array[] = isset($_array[$value])? $_array[$value] : array();
		}
		$array = array_filter($array);
		$output = '<span>'.self::get_buttons_html($array).'</span>';

		return $output;
	}
	
	
}
new Appset_Header_Config();
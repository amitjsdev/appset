<?php
add_filter( 'perch_modules/wide_class_prefix', 'appset_wide_class_prefix' );
function appset_wide_class_prefix(){
	return 'wide-';
}

add_filter( 'perch_modules/ind_class_prefix', 'appset_ind_class_prefix' );
function appset_ind_class_prefix(){
	return 'ind-';
}

add_filter( 'perch_modules/margin_top_class_prefix', 'appset_margin_top_class_prefix' );
function appset_margin_top_class_prefix(){
	return 'mt-';
}

add_filter( 'perch_modules/margin_right_class_prefix', 'appset_margin_right_class_prefix' );
function appset_margin_right_class_prefix(){
	return 'mr-';
}

add_filter( 'perch_modules/margin_bottom_class_prefix', 'appset_margin_bottom_class_prefix' );
function appset_margin_bottom_class_prefix(){
	return 'mb-';
}

add_filter( 'perch_modules/margin_left_class_prefix', 'appset_margin_left_class_prefix' );
function appset_margin_left_class_prefix(){
	return 'ml-';
}

add_filter( 'perch_modules/padding_top_class_prefix', 'appset_padding_top_class_prefix' );
function appset_padding_top_class_prefix(){
	return 'pt-';
}

add_filter( 'perch_modules/padding_right_class_prefix', 'appset_padding_right_class_prefix' );
function appset_padding_right_class_prefix(){
	return 'pr-';
}

add_filter( 'perch_modules/padding_bottom_class_prefix', 'appset_padding_bottom_class_prefix' );
function appset_padding_bottom_class_prefix(){
	return 'pb-';
}

add_filter( 'perch_modules/padding_left_class_prefix', 'appset_padding_left_class_prefix' );
function appset_padding_left_class_prefix(){
	return 'pl-';
}

function appset_sidebar_common_class(){	 
	$mbottom = appset_margin_bottom_class_prefix().'40';
	$array = array( 'sidebar-div', 'single-widget', $mbottom );

	return $array;
}

add_filter( 'perch_modules/vc_category', 'appset_vc_category' );
if( !function_exists('appset_vc_category') ){
	function appset_vc_category(){
		return 'Appset';
	}
}

add_filter( 'perch_modules/vc_class', 'appset_vc_class' );
if( !function_exists('appset_vc_class') ){
	function appset_vc_class(){
		return 'appset-vc';
	}
}

function appset_input_field_settings_options(){
    $array = array(
        'input_field' => true,
        'textarea' => false,  
        'google_font_settings' => false,          
        'typo_settings' => true,
        'highlight_settings' => true,
        'typo_std' => '',
        'highlight_std' => '',       
    );

    if( class_exists('PerchVcMap') ){
    	$array['typo_fields'] = PerchVcMap::typography_fields_settings_options();
        $array['highlight_fields'] = PerchVcMap::highlight_fields_settings_options();
    }
    return $array;
}


if (!function_exists('appset_get_option')) {
    function appset_get_option($option_id, $default = ''){
        global $appset_options;
       
        /* look for the saved value */
        if (isset($appset_options[$option_id])) {
            return $appset_options[$option_id];
        }
        return $default;
    }
}

function appset_range_option( $start, $limit, $step = 1 ) {
  if ( $step < 0 )
  $step = 1;
  $range = range( $start, $limit, $step );	
  foreach( $range as $k => $v ) {
    if ( strpos( $v, 'E' ) ) {
      $range[$k] = 0;
    }
  }

  return $range;
}
function appset_wrapper_id(){
	$id = 'page';
	$id = apply_filters( 'appset_wrapper_id', $id );
	echo sanitize_title($id);
}

function appset_wrapper_class( $class = '' ) {
	// Separates classes with a single space, collates classes for wrapper element
	echo 'class="' . join( ' ', appset_get_wrapper_class( $class ) ) . '"';
}

function appset_get_wrapper_class( $class = '' ) {
	global $wp_query;

	$classes = array('page', 'division');	

	if ( ! empty( $class ) ) {
		if ( !is_array( $class ) )
			$class = preg_split( '#\s+#', $class );
		$classes = array_merge( $classes, $class );
	} else {
		// Ensure that we always coerce class to being an array.
		$class = array();
	}

	$classes = array_map( 'esc_attr', $classes );
	$classes = apply_filters( 'appset_wrapper_class', $classes, $class );

	return array_unique( $classes );
}


function appset_header_id(){
	$id = 'header';
	$id = apply_filters( 'appset_header_id', $id );
	echo sanitize_title($id);
}

function appset_header_class( $class = '' ) {
	// Separates classes with a single space, collates classes for wrapper element
	echo 'class="' . join( ' ', appset_get_header_class( $class ) ) . '"';
}

function appset_get_header_class( $class = '' ) {
	global $wp_query;

	$classes = array('header');	

	if ( ! empty( $class ) ) {
		if ( !is_array( $class ) )
			$class = preg_split( '#\s+#', $class );
		$classes = array_merge( $classes, $class );
	} else {
		// Ensure that we always coerce class to being an array.
		$class = array();
	}

	$classes = array_map( 'esc_attr', $classes );
	$classes = apply_filters( 'appset_header_class', $classes, $class );

	return array_unique( $classes );
}

function appset_navbar_class( $class = '' ) {
	// Separates classes with a single space, collates classes for body element
	echo 'class="' . join( ' ', appset_get_navbar_class( $class ) ) . '"';
}

function appset_get_navbar_class( $class = '' ) {
	global $wp_query;

	$classes = array('navbar', 'navbar-expand-lg', 'hover-menu');		

	
	$nav_style = appset_get_option( 'nav_bg_class', 'bg-tra' );	
	$nav_style = apply_filters( 'appset/nav_bg_class', $nav_style );	

	$custom_nav_style = '';	
	if( strpos($nav_style, 'bg-custom') !==  false ){
		$custom_nav_style = appset_get_option( 'nav_bg_type' );	
		$custom_nav_style = apply_filters( 'appset/nav_bg_type', $custom_nav_style );		
	}

	$sticky_navbar = appset_get_option( 'header_sticky_nav', true );
	$sticky_navbar = apply_filters( 'appset/header_sticky_nav', $sticky_navbar );	
	
	$classes[] = $nav_style;
	if( $sticky_navbar ){
		$nav_style_scroll = appset_get_option( 'nav_style_scroll', 'black-scroll' );	
		$nav_style_scroll = apply_filters( 'appset/nav_style_scroll', $nav_style_scroll );
		$classes[] = 'fixed-top';
		$classes[] = $nav_style_scroll;

		$args = array('prefix' => '', 'postfix' => '-scroll');
		$dark_classes = appset_default_dark_color_classes($args);
		if( $custom_nav_style == 'white-color' ){
			$dark_classes[] =  $nav_style_scroll;
		}
		$classes[] = in_array($nav_style_scroll, $dark_classes)? 'scrollbg-dark' : 'scrollbg-light';

	}

	$dark_classes = appset_default_dark_color_classes();
	if( $custom_nav_style == 'white-color' ){
		$dark_classes[] =  $nav_style;
	}
	$classes[] = in_array($nav_style, $dark_classes)? 'navbar-dark' : 'navbar-light';

	if($nav_style == 'bg-tra-dark'){
		$classes[] = 'bg-tra navbar-dark';
	}
	   

	if ( ! empty( $class ) ) {
		if ( !is_array( $class ) )
			$class = preg_split( '#\s+#', $class );
		$classes = array_merge( $classes, $class );
	} else {
		// Ensure that we always coerce class to being an array.
		$class = array();
	}

	$classes = array_map( 'esc_attr', $classes );


	$classes = apply_filters( 'appset_navbar_class', $classes, $class );

	return array_unique( $classes );
}

function appset_breadcrumbs_id(){
	$id = 'breadcrumbs-hero';
	$id = apply_filters( 'appset_breadcrumbs_id', $id );
	echo sanitize_title($id);
}

function appset_breadcrumbs_class( $class = '' ) {
	// Separates classes with a single space, collates classes for wrapper element
	echo 'class="' . join( ' ', appset_get_breadcrumbs_class( $class ) ) . '"';
}

function appset_get_breadcrumbs_class( $class = '' ) {
	global $wp_query;

	$classes = array('breadcrumbs-area', 'page-hero-section', 'division', 'parallax');
	$bg_class = appset_get_option( 'header_bg_class', 'bg-light');	
	$classes[] = $bg_class;
	$dark_class = appset_default_dark_color_classes();	
	$classes[] = in_array( $bg_class, $dark_class)? 'white-color' : '';
	if( strpos($bg_class, 'bg-custom') !==  false){
  		$classes[] = appset_get_option( 'header_bg_type', '');
  	}

	if ( ! empty( $class ) ) {
		if ( !is_array( $class ) )
			$class = preg_split( '#\s+#', $class );
		$classes = array_merge( $classes, $class );
	} else {
		// Ensure that we always coerce class to being an array.
		$class = array();
	}

	$classes = array_map( 'esc_attr', $classes );
	$classes = apply_filters( 'appset_breadcrumbs_class', $classes, $class );

	return array_unique( $classes );
}

/*
* Container
*/
function appset_container_id(){
	$id = 'appset-'.get_post_type().'-content';
	if ( 'post' == get_post_type() ){
		if( is_single() ){
			$id = 'single-blog-page'; 
		}else{
			$id = 'blog-page';
		}
	}	
	$id = apply_filters( 'appset_container_id', $id );
	echo sanitize_title($id);
}

function appset_container_class( $class = '' ) {
	// Separates classes with a single space, collates classes for wrapper element
	echo 'class="' . join( ' ', appset_get_container_class( $class ) ) . '"';
}

function appset_get_container_class( $class = '' ) {
	global $wp_query;

	$classes = array('division');	
	$classes[] = 'appset-'.get_post_type().'-content';

	if ( ! empty( $class ) ) {
		if ( !is_array( $class ) )
			$class = preg_split( '#\s+#', $class );
		$classes = array_merge( $classes, $class );
	} else {
		// Ensure that we always coerce class to being an array.
		$class = array();
	}

	$classes = array_map( 'esc_attr', $classes );
	$classes = apply_filters( 'appset_container_class', $classes, $class );

	return array_unique( $classes );
}

/*
* Sidebar
*/
function appset_sidebar_id(){
	$id = 'appset-'.get_post_type().'-sidebar';
	
	$id = apply_filters( 'appset_sidebar_id', $id );
	echo sanitize_title($id);
}

function appset_sidebar_class( $class = '' ) {
	// Separates classes with a single space, collates classes for wrapper element
	echo 'class="' . join( ' ', appset_get_sidebar_class( $class ) ) . '"';
}

function appset_get_sidebar_class( $class = '' ) {
	global $wp_query;

	$classes = array('col-md-4');	
	$classes[] = 'appset-'.get_post_type().'-sidebar';

	if ( ! empty( $class ) ) {
		if ( !is_array( $class ) )
			$class = preg_split( '#\s+#', $class );
		$classes = array_merge( $classes, $class );
	} else {
		// Ensure that we always coerce class to being an array.
		$class = array();
	}

	$classes = array_map( 'esc_attr', $classes );
	$classes = apply_filters( 'appset_sidebar_class', $classes, $class );

	return array_unique( $classes );
}

/*
* Footer
*/
function appset_footer_id(){
	$id = 'footer';
	$id = apply_filters( 'appset_footer_id', $id );
	echo sanitize_title($id);
}

function appset_footer_class( $class = '' ) {
	// Separates classes with a single space, collates classes for body element
	echo 'class="' . join( ' ', appset_get_footer_class( $class ) ) . '"';
}

function appset_get_footer_class( $class = '' ) {
	global $wp_query;

	$classes = array('footer', 'division');
	$bg_class = appset_get_option( 'footer_bg_class');	
	$classes[] = $bg_class;

	$custom_bg_style = '';	
	if( strpos($bg_class, 'bg-custom') !==  false){
		$custom_style = appset_get_option( 'footer_bg_type' );	
		$custom_style = apply_filters( 'appset/custom_footer_bg_type', $custom_style );		
		$classes[] = $custom_style;
	}

	$dark_class = appset_default_dark_color_classes();
  	$classes[] = in_array( $bg_class, $dark_class)? 'white-color' : '';

	if ( ! empty( $class ) ) {
		if ( !is_array( $class ) )
			$class = preg_split( '#\s+#', $class );
		$classes = array_merge( $classes, $class );
	} else {
		// Ensure that we always coerce class to being an array.
		$class = array();
	}

	$classes = array_map( 'esc_attr', $classes );


	$classes = apply_filters( 'appset_footer_class', $classes, $class );

	return array_unique( $classes );
}

/*
* Newsletter
*/
function appset_newsletter_id(){
	$id = 'newsletter-1';
	$id = apply_filters( 'appset_footer_id', $id );
	echo sanitize_title($id);
}

function appset_newsletter_class( $class = '' ) {
	// Separates classes with a single space, collates classes for body element
	echo 'class="' . join( ' ', appset_get_newsletter_class( $class ) ) . '"';
}

function appset_get_newsletter_class( $class = '' ) {
	global $wp_query;

	$classes = array('newsletter-section', 'wide-80', 'division', 'parallax');
	$bg_class = appset_get_option( 'newsletter_bg_class');	
	$classes[] = $bg_class;

	$custom_bg_style = '';	
	if( strpos($bg_class, 'bg-custom') !==  false){
		$custom_style = appset_get_option( 'newsletter_bg_type' );	
		$custom_style = apply_filters( 'appset/custom_newsletter_bg_type', $custom_style );		
		$classes[] = $custom_style;
	}

	$dark_class = appset_default_dark_color_classes();
  	$classes[] = in_array( $bg_class, $dark_class)? 'white-color' : '';

	if ( ! empty( $class ) ) {
		if ( !is_array( $class ) )
			$class = preg_split( '#\s+#', $class );
		$classes = array_merge( $classes, $class );
	} else {
		// Ensure that we always coerce class to being an array.
		$class = array();
	}

	$classes = array_map( 'esc_attr', $classes );


	$classes = apply_filters( 'appset_newsletter_class', $classes, $class );

	return array_unique( $classes );
}

add_filter( 'perch_modules/supported_social_links', 'appset_default_social_links_callback' );
function appset_default_social_links_callback($array = array()){
	$new_array = array(
		'500px' 		=> array( 'title' => '500px', 'url' => '#', 'icon' => 'fab fa-500px', ),
		'amazon' 		=> array( 'title' => 'Amazon', 'url' => '#', 'icon' => 'fab fa-amazon', ),
		'adn' 			=> array( 'title' => 'Adn', 'url' => '#', 'icon' => 'fab fa-adn', ),
		'android' 		=> array( 'title' => 'Android', 'url' => '#', 'icon' => 'fab fa-android', ),
		'angellist' 	=> array( 'title' => 'Angel list', 'url' => '#', 'icon' => 'fab fa-angellist', ),
		'bandcamp' 		=> array( 'title' => 'Bandcamp', 'url' => '#', 'icon' => 'fab fa-bandcamp', ),
		'behance' 		=> array( 'title' => 'Behance', 'url' => '#', 'icon' => 'fab fa-behance', ),
		'bitbucket' 	=> array( 'title' => 'Bitbucket', 'url' => '#', 'icon' => 'fab fa-bitbucket', ),
		'bitcoin' 		=> array( 'title' => 'Bitcoin', 'url' => '#', 'icon' => 'fab fa-bitcoin', ),
		'codepen' 		=> array( 'title' => 'Codepen', 'url' => '#', 'icon' => 'fab fa-codepen', ),
		'delicious' 	=> array( 'title' => 'Delicious', 'url' => '#', 'icon' => 'fab fa-delicious', ),
		'digg' 			=> array( 'title' => 'Digg', 'url' => '#', 'icon' => 'fab fa-digg', ),
		'dribbble' 		=> array( 'title' => 'Dribbble', 'url' => '#', 'icon' => 'fab fa-dribbble', ),
		'dropbox' 		=> array( 'title' => 'Dropbox', 'url' => '#', 'icon' => 'fab fa-dropbox', ),
		'facebook' 		=> array( 'title' => 'Facebook', 'url' => '#', 'icon' => 'fab fa-facebook-f', ),
		'flickr' 		=> array( 'title' => 'Flickr', 'url' => '#', 'icon' => 'fab fa-flickr', ),
		'git' 			=> array( 'title' => 'Git', 'url' => '#', 'icon' => 'fab fa-git', ),
		'github' 		=> array( 'title' => 'Github', 'url' => '#', 'icon' => 'fab fa-github', ),	
		'gitlab' 		=> array( 'title' => 'Gitlab', 'url' => '#', 'icon' => 'fab fa-gitlab', ),
		'google-plus' 	=> array( 'title' => 'Google-plus', 'url' => '#', 'icon' => 'fab fa-google-plus', ),
		'instagram' 	=> array( 'title' => 'Instagram', 'url' => '#', 'icon' => 'fab fa-instagram', ),
		'jsfiddle' 		=> array( 'title' => 'jsfiddle', 'url' => '#', 'icon' => 'fab fa-jsfiddle', ),
		'linkedin' 		=> array( 'title' => 'Linkedin', 'url' => '#', 'icon' => 'fab fa-linkedin', ),
		'linux' 		=> array( 'title' => 'Linux', 'url' => '#', 'icon' => 'fab fa-linux', ),
		'linode' 		=> array( 'title' => 'Linode', 'url' => '#', 'icon' => 'fab fa-linode', ),
		'medium' 		=> array( 'title' => 'Medium', 'url' => '#', 'icon' => 'fab fa-medium', ),
		'meetup' 		=> array( 'title' => 'Meetup', 'url' => '#', 'icon' => 'fab fa-meetup', ),
		'odnoklassniki' => array( 'title' => 'Odnoklassniki', 'url' => '#', 'icon' => 'fab fa-odnoklassniki', ),
		'paypal' 		=> array( 'title' => 'Paypal', 'url' => '#', 'icon' => 'fab fa-paypal', ),
		'pinterest' 	=> array( 'title' => 'Pinterest', 'url' => '#', 'icon' => 'fab fa-pinterest', ),
		'reddit' 		=> array( 'title' => 'Reddit', 'url' => '#', 'icon' => 'fab fa-reddit', ),
		'scribd' 		=> array( 'title' => 'Scribd', 'url' => '#', 'icon' => 'fab fa-scribd', ),
		'share' 		=> array( 'title' => 'Share-alt', 'url' => '#', 'icon' => 'fab fa-share-alt', ),
		'skype' 		=> array( 'title' => 'Skype', 'url' => '#', 'icon' => 'fab fa-skype', ),
		'slack' 		=> array( 'title' => 'Slack', 'url' => '#', 'icon' => 'fab fa-slack', ),
		'soundcloud' 	=> array( 'title' => 'Soundcloud', 'url' => '#', 'icon' => 'fab fa-soundcloud', ),
		'stack-exchange' => array( 'title' => 'Stack-exchange', 'url' => '#', 'icon' => 'fab fa-stack-exchange', ),
		'stack-overflow' => array( 'title' => 'Stack-overflow', 'url' => '#', 'icon' => 'fab fa-stack-overflow', ),
		'stumbleupon' 	=> array( 'title' => 'Stumbleupon', 'url' => '#', 'icon' => 'fab fa-stumbleupon', ),
		'trello' 		=> array( 'title' => 'Trello', 'url' => '#', 'icon' => 'fab fa-trello', ),
		'tumblr' 		=> array( 'title' => 'Tumblr', 'url' => '#', 'icon' => 'fab fa-tumblr', ),
		'twitter' 		=> array( 'title' => 'Twitter', 'url' => '#', 'icon' => 'fab fa-twitter', ),
		'vimeo' 		=> array( 'title' => 'Vimeo', 'url' => '#', 'icon' => 'fab fa-vimeo', ),
		'vk' 			=> array( 'title' => 'VK', 'url' => '#', 'icon' => 'fab fa-vk', ),
		'whatsapp' 		=> array( 'title' => 'Whatsapp', 'url' => '#', 'icon' => 'fab fa-whatsapp', ),
		'wikipedia' 	=> array( 'title' => 'Wikipedia', 'url' => '#', 'icon' => 'fab fa-wikipedia-w', ),
		'wordpress' 	=> array( 'title' => 'WordPress', 'url' => '#', 'icon' => 'fab fa-wordpress', ),
		'xing' 			=> array( 'title' => 'Xing', 'url' => '#', 'icon' => 'fab fa-xing', ),
		'yahoo' 		=> array( 'title' => 'Yahoo', 'url' => '#', 'icon' => 'fab fa-yahoo', ),
		'yelp' 			=> array( 'title' => 'Yelp', 'url' => '#', 'icon' => 'fab fa-yelp', ),
		'youtube' 		=> array( 'title' => 'Youtube', 'url' => '#', 'icon' => 'fab fa-youtube', ),

	);
	$array = array_merge($array, $new_array );
	return $array;
}

add_filter( 'perch_modules/supported_buttons', 'appset_default_buttons_set_callback' );
function appset_default_buttons_set_callback($array = array()){
	$new_array = array(
		'btn1' => array(
			'name' => 'Amazon - image', 
			'title' => 'Buy on amazon', 
			'type' => 'image',
			'url' => '#', 
			'target'=> '_blank',
			'image'=>APPSET_URI.'/images/amazon.png',
			'style' => ''
		),
		'btn2' => array(
			'name' => 'App store - image', 
			'title' => 'App store', 
			'type' => 'image',
			'url' => '#', 
			'target'=> '_blank',
			'image'=>APPSET_URI.'/images/appstore.png',
			'style' => ''
		),
		'btn3' => array(
			'name' => 'Google play - image', 
			'title' => 'Google play', 
			'type' => 'image',
			'url'=>'#',
			'target'=> '_blank',
			'image'=>APPSET_URI.'/images/googleplay.png',
			'style' => ''
		),
		'btn4' => array(
			'name' => 'Get started - text button', 
			'title' => 'Get started', 
			'type' => 'text',
			'url'=>'#',
			'target'=> '_self',
			'style' => ''
		),
		'btn5' => array(
			'name' => 'Contact us - text button', 
			'title' => 'Contact us', 
			'type' => 'text',
			'url'=>'#',
			'target'=> '_self',
			'style' => ''
		),
	);
	$array = array_merge($array, $new_array );

	return $array;
}

function appset_supported_social_links(){
	$array = appset_default_social_links_callback();

	$options = get_option('appset_settings', array());
	if( !empty($options) ):			
	$array = $options['social_links_group'];
	//$array = apply_filters( 'perch_modules/supported_social_links_meta', $array, $meta );
	endif;
	
	return $array;
}

function appset_supported_buttons(){
	$array = appset_default_buttons_set_callback();	

	$options = get_option('appset_settings', array());
	if( !empty($options) ):			
	$array = $options['buttons_group'];
	//$array = apply_filters( 'perch_modules/supported_buttons_meta', $array, $meta );
	endif;	
	return $array;
}

function appset_supported_social_links_callback($array = array()){	
	$supported = appset_supported_social_links();
	foreach ($supported as $key => $value) {
		$array[$key] = $value['title'];
	}
	return $array;
}


function appset_supported_buttons_callback($array = array()){	
	$supported = appset_supported_buttons();
	foreach ($supported as $key => $value) {		
		$array[$key] = $value['name'];
	}
	return $array;
}

function appset_general_options_social_link(){
	return array('facebook','twitter', 'linkedin', 'tumblr');
}

function appset_predefined_page_templates( $array = array() ){
	$_array = array(
		'blog' => array(
			'title' => __('Blog page', 'appset'),
			'id' => 'blog-page',
			'class' => 'wide-100 blog-page-section division',
			'sidebar' => array(
				'id' => 'sidebar-right',
				'class' => '',
			),
		),
		'faqs' => array(
			'title' => __('Faq page', 'appset'),
			'id' => 'faqs-page',
			'class' => 'bg-fixed download-section division',
		),
		'terms' => array(
			'title' => __('Terms page', 'appset'),
			'id' => 'terms-page',
			'class' => 'terms-section division',
		),
		'download' => array(
			'title' => __('Download page', 'appset'),
			'id' => 'download-page',
			'class' => 'bg-fixed download-section division',
		)
	);
	return array_merge($array, $_array);
}
add_filter( 'perch_modules/predefined_page_templates', 'appset_predefined_page_templates' );

function appset_predefined_page_templates_options(){
	$array = appset_predefined_page_templates();
	$output = array();
	if( !empty($array) ):
		foreach ($array as $key => $value) {
			$output[$key] = $value['title'];
		}
	endif;

	return $output;
}

function appset_get_predefined_template_attr( $id = NULL, $attr = 'class'  ){
	$array = appset_predefined_page_templates();
	if( $id == NULL ) return false;
	if( !isset($array[$id]) ) return false;
	$template = $array[$id];
	if( !isset($template[$attr]) ) return false;
	$output = $template[$attr];
	return $output;
}

function appset_set_default_vc_values($default, $args){
	
	foreach ($default as $key => $value) {
        $arrKey = array_search($key, array_column($args, 'param_name'));
        if( !is_array($value) ){
        	if( isset($args[$arrKey]['value']) && is_array($args[$arrKey]['value']) ){
            	$args[$arrKey]['std'] = $value;
	        }elseif( isset($args[$arrKey]['settings']) && is_array($args[$arrKey]['settings']) ){
	        	$args[$arrKey]['std'] = $value;
	        }else{
	            $args[$arrKey]['value'] = $value;
	        }
        }else{
        	$args[$arrKey] = array_merge($args[$arrKey], $value );        	
        }       
    }

    return $args;
}

function appset_range_css_option($prefix, $property, $args = array()){
	$default = array('start' => 0, 'limit' => 10, 'step' => 1, 'unit' => 'px');
	extract(shortcode_atts($default , $args));

   	$range = appset_range_option( $start, $limit, $step );
	$array = array();
    foreach( $range as $k => $v ) {
      $array[] = $prefix.$v. ' { '.$property.': '. $v . $unit . '; }';
    } 

   return apply_filters( 'perch_vc_dropdown_options', $array );
}


function appset_spacing_css_style(){

  	$css = '';
  	// Wide
  	$wide = '.'.appset_wide_class_prefix();
	$arr = appset_range_css_option( $wide, 'padding-bottom', array('limit' => 200, 'step' => 10));
	$css .= implode(' ', $arr);
	$arr = appset_range_css_option( $wide, 'padding-top', array('start' => 100, 'limit' => 200, 'step' => 10));
	$css .= implode(' ', $arr);

	// Ind
	$ind = '.'.appset_ind_class_prefix();
	$arr = appset_range_css_option($ind, 'padding-left', array('limit' => 150, 'step' => 5));
	$css .= implode(' ', $arr);
	$arr = appset_range_css_option($ind, 'padding-right', array('limit' => 150, 'step' => 5));
	$css .= implode(' ', $arr);

	// Margin
	$args = array('limit' => 200, 'step' => 5);
	$mtop  		= '.'.appset_margin_top_class_prefix();
	$arr = appset_range_css_option($mtop, 'margin-top', $args );
	$css .= implode(' ', $arr);

	$mright  		= '.'.appset_margin_right_class_prefix(); 
	$arr = appset_range_css_option($mright, 'margin-right', $args );
	$css .= implode(' ', $arr);

	$mbottom  	= '.'.appset_margin_bottom_class_prefix(); 
	$arr = appset_range_css_option($mbottom, 'margin-bottom', $args );
	$css .= implode(' ', $arr);

	$mleft  	= '.'.appset_margin_left_class_prefix();
	$arr = appset_range_css_option($mleft, 'margin-left', $args );
	$css .= implode(' ', $arr);

	// Padding
	$args = array('limit' => 200, 'step' => 5);
	$ptop = '.'.appset_padding_top_class_prefix();
	$arr = appset_range_css_option($ptop, 'padding-top', $args );
	$css .= implode(' ', $arr);
	$pbottom = '.'.appset_padding_bottom_class_prefix();
	$arr = appset_range_css_option($pbottom, 'padding-bottom', $args );
	$css .= implode(' ', $arr);
	$pleft = '.'.appset_padding_left_class_prefix();
	$arr = appset_range_css_option($pleft, 'padding-left', $args );
	$css .= implode(' ', $arr);
	$pright = '.'.appset_padding_right_class_prefix();
	$arr = appset_range_css_option($pright, 'padding-right', $args );
	$css .= implode(' ', $arr);

  	return $css;
}
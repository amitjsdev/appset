<?php
/**
 * Initialize the meta boxes. 
 */

add_action( 'admin_init', 'appset_general_onepage_meta_boxes' );
if( !function_exists('appset_general_onepage_meta_boxes') ):
function appset_general_onepage_meta_boxes() {
    $screen = get_current_screen(); 

    $my_meta_box = array(
        'id'        => 'appset_template_sttings_boxes',
        'title'     => __('Appset page template Settings', 'appset'),
        'desc'      => '',
        'pages'     => array( 'page' ),
        'context'   => 'side',
        'priority'  => 'high',
        'fields'    =>  array(
            array(
                'id' => 'appset_template_type',
                'label' => __('Page template type', 'appset'),
                'desc' => '',
                'std' => '',
                'type' => 'select',
                'choices' => array(           
                array( 'label' => 'Default', 'value' => '' ),
                array( 'label' => 'Landing page template', 'value' => 'landing' ),
                array( 'label' => 'Front page template', 'value' => 'frontpage' )
                )
            ),
        ),

      );
    ot_register_meta_box( $my_meta_box );   


    $navarr = array(
            array(
                 'id' => 'nav_general_option_tab',
                'label' => __( 'General settings', 'appset' ),
                'desc' => __( 'Display social Icon or Buttons', 'appset' ),
                'type' => 'tab',
                'section' => 'header_options',
                //'class' => 'half-column-size', 
            ),
            array(
                'id' => 'one_page_wp_nav',
                'label' => __('Select Nav menu', 'appset'),
                'desc' => '<a href="' . admin_url( 'nav-menus.php' ) . '" class="nav-link">' . __( 'Add a menu', 'appset' ) . '</a>',
                'std' => '',
                'type' => 'select',
                'choices' => appset_get_terms_choices('nav_menu')
            ),
        ); 



      $my_meta_box = array(
        'id'        => 'appset_onepage_sttings_boxes',
        'title'     => __('Landing Page Navbar Settings', 'appset'),
        'desc'      => '',
        'pages'     => array( 'page' ),
        'context'   => 'normal',
        'priority'  => 'high',
        'fields'    =>  array_merge($navarr, appset_header_options())

      );
      ot_register_meta_box( $my_meta_box );

      $my_meta_box = array(
        'id'        => 'appset_onepage_footer_sttings_boxes',
        'title'     => __('Landing Page footer Settings', 'appset'),
        'desc'      => '',
        'pages'     => array( 'page' ),
        'context'   => 'normal',
        'priority'  => 'high',
        'fields'    => array(
            array(
                 'id' => 'onepage_footer_display',
                'label' => __( 'Footer display', 'appset' ),
                'type' => 'on-off',
                'std' => 'on',
                //'class' => 'half-column-size', 
            ),
            array(
                 'id' => 'quickform_area',
                'label' => __( 'Quick contact form Display','appset' ),
                'desc' => __( 'Display in bottom of page','appset' ),
                'std' => 'off',
                'type' => 'on-off',
                'section' => 'footer_options' 
            ),
            array(
                'id' => 'footer_bg_style',
                'label' => __('Footer background style', 'appset'),
                'desc' => '',
                'std' => appset_get_option( 'footer_bg_style', 'bg-tra' ),
                'type' => 'select',
                'choices' => appset_bg_color_options(),
            ),
        )

      );
      ot_register_meta_box( $my_meta_box );

}
endif;
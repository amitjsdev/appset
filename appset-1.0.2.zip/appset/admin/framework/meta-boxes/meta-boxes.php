<?php
/**
 * Includes meta boxes. 
 */
load_template(APPSET_DIR . "/admin/framework/meta-boxes/meta-boxes-post-formats.php") ;
load_template(APPSET_DIR . "/admin/framework/meta-boxes/meta-boxes-template-settings.php") ;
load_template(APPSET_DIR . "/admin/framework/meta-boxes/meta-boxes-header-settings.php") ;


add_filter( 'rwmb_meta_boxes', 'appset_register_header_settings_meta_boxes' );
function appset_register_header_settings_meta_boxes( $meta_boxes ) {
    $meta_boxes[] = array (
        'title' => 'Appset settings',
        'id' => 'appset-page-settings',
        'post_types' => array('page'),
        'priority' => 'high',
        'autosave' => true,
        'default_hidden' => true,        
        'fields' => appset_header_settings_meta_boxes(),
        'tab_style' => 'default',
        'tab_wrapper' => true,
        'tabs' => array(
            'General_settings' => array(
                'label' => 'General settings',
                'icon' => 'dashicons-admin-generic',
            ),
            'navbar_settings' => array(
                'label' => 'Header settings',
                'icon' => 'dashicons-admin-settings',
            ),
        ),
    );
    

    return $meta_boxes;
}

add_action( 'portfolio_category_add_form_fields', 'appset_portfolio_category_add_form_fields', 10, 2 );
function appset_portfolio_category_add_form_fields($taxonomy) {   

    ?><div class="form-field term-group">
        <label for="custom-link"><?php _e('Custom Category link', 'appset'); ?></label>
        <input name="custom-link" id="custom-link" value="" size="40" type="text">
        <p>Leave blank to avoid custom link. Default term link will be used.</p>
    </div><?php
}

add_action( 'created_portfolio_category', 'appset_save_portfolio_category_meta', 10, 2 );
function appset_save_portfolio_category_meta( $term_id, $tt_id ){

    if( isset( $_POST['custom-link'] ) && '' !== $_POST['custom-link'] ){
        $link = esc_url( $_POST['custom-link'] );
        add_term_meta( $term_id, 'custom-link', $link, true );
    }

}

add_action( 'portfolio_category_edit_form_fields', 'appset_portfolio_category_edit_form_fields', 10, 2 );
function appset_portfolio_category_edit_form_fields( $term, $taxonomy ){

    // get current group
    $link = get_term_meta( $term->term_id, 'custom-link', true );                

    ?><tr class="form-field term-group-wrap">
        <th scope="row"><label for="custom-link"><?php _e('Custom Category link', 'appset'); ?></label></th>
        <td><input name="custom-link" id="custom-link" value="<?php echo esc_url($link) ?>" size="40" type="text">
       </td>
    </tr><?php
}

add_action( 'edited_portfolio_category', 'appset_edited_portfolio_category', 10, 2 );
function appset_edited_portfolio_category( $term_id, $tt_id ){

    if( isset( $_POST['custom-link'] ) && '' !== $_POST['custom-link'] ){
        $link = esc_url( $_POST['custom-link'] );
        update_term_meta( $term_id, 'custom-link', $link );
    }
}
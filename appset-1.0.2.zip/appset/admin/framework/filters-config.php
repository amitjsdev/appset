<?php
add_filter( 'appset/nav_style_scroll', 'appset_nav_style_scroll', 10, 1 );
add_filter( 'appset/header_sticky_nav', 'appset_header_sticky_nav', 10, 1 );
add_filter( 'appset/nav_bg_class', 'appset_nav_bg_class', 10, 1 );
add_filter( 'appset/nav_bg_gradient', 'appset_nav_bg_gradient', 10, 1 );
add_filter( 'appset/nav_bg_gradient_type', 'appset_nav_bg_gradient_type', 10, 1 );
add_filter( 'appset/nav_bg_color', 'appset_nav_bg_custom_color', 10, 1 );
add_filter( 'appset/nav_bg_type', 'appset_custom_nav_bg_type', 10, 1 );
add_filter( 'appset/navbar_style', 'appset_navbar_style', 10, 1 );
add_filter( 'appset/logo_type', 'appset_page_logo_type', 10, 1 );	
add_filter( 'appset/get_logo', 'appset_get_logo', 10, 3 );	
add_filter( 'appset/header_search_display', 'appset_header_search_display', 10, 1 );
add_filter( 'appset/nav_search_placeholder', 'appset_nav_search_placeholder', 10, 1 );	
add_filter( 'appset/header_social_icons_display', 'appset_header_social_icons_display', 10, 1 );	
add_filter( 'appset/header_social_icons', 'appset_header_social_icons', 10, 1 );	
add_filter( 'appset/header_button_display', 'appset_header_button_display', 10, 1 );	
add_filter( 'appset/header_buttons', 'appset_header_buttons', 10, 1 );	
add_filter( 'perch_modules/perch_buttons/color/options', 'appset_button_scolor_options', 10, 1 );
		


function appset_button_scolor_options($array){
	$new_array = appset_redux_options(appset_btn_style_options(false));
	return array_merge($array, $new_array);
}
function appset_get_post_group_meta( $output, $group_id = '', $opt_name = '', $default = '' ){
	$output = $default;
	if($group_id == '') return $output;
	if($opt_name == '') return $output;

	if( function_exists('rwmb_meta')  ) {
		$meta = rwmb_meta( $group_id );		
		$output = !isset($meta[$opt_name])? false : $output;	
	}
		
	
	if( isset($meta[$opt_name]) && ($meta[$opt_name] != '') ){
		return $meta[$opt_name];
	}else{			
		return $output;
	}
}

function appset_header_social_icons($output){
	$opt_name = 'header_social_icons';
	$group_id = 'navbar_icon_settings';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_icon_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );		
	}			
	return $output;
}

function appset_header_social_icons_display($output){
	$opt_name = 'header_social_icons_display';
	$group_id = 'navbar_icon_settings';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_icon_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );
	}			
	return $output;
}

function appset_header_button_display($output){
	$opt_name = 'header_button_display';
	$group_id = 'navbar_icon_settings';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_icon_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );		
	}			
	return $output;
}

function appset_header_buttons($output){
	$opt_name = 'header_buttons';
	$group_id = 'navbar_icon_settings';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_icon_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );			
	}			
	return $output;
}

function appset_header_search_display($output){
	$opt_name = 'header_search_display';
	$group_id = 'navbar_icon_settings';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_icon_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );
	}			
	return $output;
}

function appset_nav_search_placeholder($output){
	$opt_name = 'nav_search_placeholder';
	$group_id = 'navbar_icon_settings';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_icon_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );
	}			
	return $output;
}

function appset_nav_style_scroll($output){
	$opt_name = 'nav_style_scroll';
	$group_id = 'navbar_settings_group';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );
	}			
	return $output;
}

function appset_header_sticky_nav($output){
	$opt_name = 'header_sticky_nav';
	$group_id = 'navbar_settings_group';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_settings')){
		$output = false;
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );
	}

	return $output;
}

function appset_nav_bg_class($output){

	$opt_name = 'nav_bg_class';
	$group_id = 'navbar_settings_group';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_settings')){		
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );
	}			
	return $output;
}

function appset_nav_bg_gradient($output){
	$opt_name = 'nav_bg_gradient';
	$group_id = 'navbar_settings_group';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );
	}			
	return $output;
}

function appset_nav_bg_gradient_type($output){
	$opt_name = 'nav_bg_gradient_type';
	$group_id = 'navbar_settings_group';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );
	}			
	return $output;
}

function appset_nav_bg_custom_color($output){
	$opt_name = 'nav_bg_color';
	$group_id = 'navbar_settings_group';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );
	}			
	return $output;
}

function appset_custom_nav_bg_type($output){
	$opt_name = 'nav_bg_type';
	$group_id = 'navbar_settings_group';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );
	}			
	return $output;
}

function appset_navbar_style($output){
	$opt_name = 'navbar_style';
	$group_id = 'navbar_settings_group';
	if(function_exists('rwmb_meta') && rwmb_meta('custom_nav_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );
	}			
	return $output;
}

function appset_page_logo_type($output){
	$opt_name = 'logo_type';
	$group_id = 'logo_settings_group';

	if(function_exists('rwmb_meta') && rwmb_meta('custom_logo_settings')){
		$output = appset_get_post_group_meta($output, $group_id, $opt_name );
	}			
	return $output;
}

function appset_get_logo($output, $logo_type, $dark){
	$group_id = 'logo_settings_group';
	
	if(function_exists('rwmb_meta') && rwmb_meta('custom_logo_settings')):	

		$opt_name = ( $dark )? 'logo_white' : 'logo';
		if( $logo_type == 'image' ){
			$image_url = appset_get_post_group_meta($output, $group_id, $opt_name);
			//$image = RWMB_Image_Field::file_info( $image_id, array( 'size' => 'full' ) );		

			$output = $image_url;
		}

		// text logo
		$opt_name = 'logo_text';
		if( $logo_type == 'text' ){
			$logo = appset_get_post_group_meta($output, $group_id, $opt_name);
			$output = $logo;		
		}

	endif;

	return $output;
}


add_filter( 'perch_modules/vc_spacing_options_param', 'appset_spacing_options_param', 10, 4 );
function appset_spacing_options_param($arr, $type, $pos, $name ){
	$new_array = appset_vc_spacing_options($type, $pos);
	$arr = array_merge($arr, $new_array);
	return $arr;
}
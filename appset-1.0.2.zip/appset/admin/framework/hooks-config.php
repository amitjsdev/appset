<?php
defined( 'ABSPATH' ) || exit;
/*
* Appset hooks class
*/

add_action( 'appset/preloader', 'appset_preloader_template_part', 10 );
// header hook
add_action( 'appset/header', 'appset_navbar_template_part', 10 );
add_action( 'appset/header', 'appset_breadcrumbs_template_part', 15 );
add_action( 'appset/header/logo', 'appset_header_logo', 10 );
add_action( 'appset/header/menu', 'appset_header_mobile_menu_icon', 10 );
add_action( 'appset/header/menu', 'appset_header_nav_menu', 15 );
add_action( 'appset/header/menu/after', 'appset_header_nav_menu_after', 10 );
//footer hooks
add_action( 'appset/footer/before', 'appset_newsletter_form_template_part', 10 );
add_action( 'appset/footer', 'appset_footer_widget_area_template_part', 10 );
add_action( 'appset/footer', 'appset_footer_copyright_template_part', 20 );
add_action( 'appset/footer/after', 'appset_quick_contact_form_template_part', 10 );
add_action( 'appset_post_format', 'appset_post_format_callback', 10 );


function appset_post_format_callback(){	
	global $post;

	$enable_video = get_post_meta( $post->ID, 'enable_video_popup', true );

	if( $enable_video ){
		get_template_part( 'template-parts/post/format', 'video' );
	}else{
		get_template_part( 'template-parts/post/format', 'image' );
	}
}


if( !function_exists( 'appset_newsletter_form_template_part' ) ):
function appset_newsletter_form_template_part(){
	get_template_part( 'footer/newsletter' );
}
endif;

if( !function_exists( 'appset_footer_copyright_template_part' ) ):
function appset_footer_copyright_template_part(){
	get_template_part( 'footer/copyright' );
}
endif;

if( !function_exists( 'appset_quick_contact_form_template_part' ) ):
function appset_quick_contact_form_template_part(){
	get_template_part( 'footer/quick-form' );
}
endif;

if( !function_exists( 'appset_footer_widget_area_template_part' ) ):
function appset_footer_widget_area_template_part(){
	get_template_part( 'footer/widget-area' );
}
endif;

if( !function_exists( 'appset_preloader_template_part' ) ):
function appset_preloader_template_part(){
	get_template_part( 'header/preloader' );
}
endif;

if( !function_exists( 'appset_navbar_template_part' ) ):
function appset_navbar_template_part(){
	get_template_part( 'header/navbar', Appset_Header_Config::get_navbar_style() );
}
endif;

if( !function_exists( 'appset_breadcrumbs_template_part' ) ):
function appset_breadcrumbs_template_part(){
	get_template_part( 'header/breadcrumbs' );
}
endif;

if( !function_exists( 'appset_header_logo' ) ):
function appset_header_logo(){
	get_template_part( 'header/logo', Appset_Header_Config::get_logo_type() );
}
endif;

if( !function_exists( 'appset_header_mobile_menu_icon' ) ):
function appset_header_mobile_menu_icon(){
	get_template_part( 'header/mobilemenu', 'icon' );
}
endif;

if( !function_exists( 'appset_header_nav_menu' ) ):
function appset_header_nav_menu(){
	get_template_part( 'header/navigation' );
}
endif;

if( !function_exists( 'appset_header_nav_menu_after' ) ):
function appset_header_nav_menu_after(){
	if(Appset_Header_Config::get_navbar_style() == 'style2'){
		get_template_part( 'header/navigation', 'after' );
	}	
}
endif;
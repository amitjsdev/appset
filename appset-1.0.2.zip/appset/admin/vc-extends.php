<?php
include APPSET_DIR . '/admin/vc-icons.php';

if ( function_exists( 'vc_set_as_theme' ) ):
    vc_set_as_theme( $disable_updater = false );
endif;
$dir = get_template_directory() . '/vc_templates';
vc_set_shortcodes_templates_dir( $dir );



function appset_vc_column_class_options(){
    $array = array(
        '' => 'None',
        'content-boxes' => 'Content box',
        'content-txt' => 'Content Text', 
        'hero-txt' => 'Hero Text',
        'box-rounded' => 'Rounded border',
        'hero-img' => 'Hero image',
        'content-img' => 'Content image',
        'features-img' => 'Features image',
        'download-img' => 'Download image',
    );
    $new_arr = array();
    foreach ($array as $key => $value) {
        $new_arr["{$value}"] = $key;
    }
    return $new_arr;
}

add_filter( 'vc_font_container_output_data', 'appset_vc_font_container_output_data', 10, 4 );
function appset_vc_font_container_output_data( $data, $fields, $values, $settings ){
   $r = json_encode($values);
    $data['color'] = '
        <div class="vc_row-fluid vc_column vc_col-sm-4">
            <div class="wpb_element_label">' . __( 'Text color', 'appset' ) . '</div>
            <div class="vc_font_container_form_field-color-container">
                <select class="vc_font_container_form_field-color-input">';
        $colors = appset_vc_color_options(false);
        foreach ( $colors as $color ) {
            $data['color'] .= '<option value="' . $color . '" class="' . $color . '" ' . ( $values['color'] == $color ? 'selected' : '' ) . '>' . $color . '</option>';
        }
        $data['color'] .= '
                </select>
            </div>';
        if ( isset( $fields['color_description'] ) && strlen( $fields['color_description'] ) > 0 ) {
            $data['color'] .= '
            <span class="vc_description clear">' . $fields['color_description'] . '</span>
            ';
        }

    $data['color'] .= '</div>';

    

    return $data;            
}


function appset_vc_hero_options(){
    $array = array('Layout 1', 'Layout 2', 'Layout 3', 'Layout 4', 'Layout 5',
        'Layout 6', 'Layout 7', 'Layout 8', 'Layout 9', 'Layout 10',
        'Layout 11', 'Layout 12');
    $new_arr = array();
    foreach ($array as $key => $value) {
        $new_arr["{$value}"] = ($key+1);
    }
    return $new_arr;
}

add_action( 'vc_after_init', 'appset_vc_typography_param_options' );
function appset_vc_typography_param_options(){
    $hl_group = __( 'Title options', 'appset' );
    $hl_dep = array( 'element' => 'custom_title', 'value' => 'yes' );
    $newParamData = array(
        array(
            'type' => 'textfield',
            'value' => 'We bring the best things',
            'heading' => 'Title',
            'param_name' => 'title',
            'admin_label' => true,
            'edit_field_class' => 'vc_col-sm-8', 
        ),
        array(
            'type' => 'checkbox',
            'heading' => __( 'Custom title options?', 'appset' ),
            'param_name' => 'custom_title',
            'value' => array( __( 'Yes', 'appset' ) => 'yes' ), 
            'admin_label' => true,
            'edit_field_class' => 'vc_col-sm-4',
        ), 
        array(
            'type' => 'dropdown',
            'heading' => 'Title tag',
            'param_name' => 'title_tag',
            'value' => appset_vc_tag_options(),
            'std' => 'h3',
            'group' => $hl_group,
            'edit_field_class' => 'vc_col-sm-4', 
            'dependency' => $hl_dep,
        ),
        array(
            'type' => 'dropdown',
            'heading' => 'Size',
            'param_name' => 'title_size',
            'value' => appset_vc_size_class_options(),
            'group' => $hl_group,
            'edit_field_class' => 'vc_col-sm-4', 
            'dependency' => $hl_dep,
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Title color', 'appset' ),
            'param_name' => 'title_color',
            'value' => appset_vc_color_options(false),
            'group' => $hl_group,
            'edit_field_class' => 'vc_col-sm-4', 
            'dependency' => $hl_dep,
        ),
       

         
    );
    foreach ( $newParamData as $key => $value ) {       
        vc_update_shortcode_param( 'appset_title_area', $value );
    }
}

add_action( 'vc_after_init', 'appset_vc_heighlights_text_param_options' );
function appset_vc_heighlights_text_param_options(){
    $hl_group = __( 'Highlight text options', 'appset' );
    $hl_dep = array( 'element' => 'highlight_text', 'value' => 'yes' );
    $newParamData = array(
        array(
            'type' => 'checkbox',
            'heading' => __( 'Enable highlight text options?', 'appset' ),
            'param_name' => 'highlight_text',
            'description' => __( 'Checked to select enable highlight text option', 'appset' ),
            'value' => array( __( 'Yes', 'appset' ) => 'yes' ), 
            'admin_label' => true
        ), 
        array(
             'type' => 'dropdown',
            'heading' => __( 'Underline for highlight text', 'appset' ),
            'param_name' => 'highlight_text_underline',
            'value' => appset_vc_underline_color_options(),
            'std' => 'underline-yellow',
            'group' => $hl_group,
            'dependency' => $hl_dep, 
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Highlight text bg', 'appset' ),
            'param_name' => 'highlight_text_bg',
            'value' => appset_vc_background_options(true),
            'group' => $hl_group,  
            'std' => '',
            'description' => __( 'Only worked for highlighted text', 'appset' ),
            'dependency' => $hl_dep,  
        ),
        array(
             'type' => 'dropdown',
            'heading' => __( 'Highlight text color', 'appset' ),
            'param_name' => 'highlight_text_color',
            'value' => appset_vc_color_options(true),
            'std' => '',
            'group' => $hl_group,
            'dependency' => $hl_dep,
        ),
       appset_vc_tag_options_param( 'highlight_text_tag', 'Highlight text tag', 'span', $hl_group, $hl_dep ),
       appset_vc_size_options_param( 'highlight_text_size', 'Title size', '', $hl_group, $hl_dep ),
       appset_vc_weight_options_param( 'highlight_text_weight', 'Title weight', '', $hl_group, $hl_dep ),
       
        appset_vc_animation_type('fadeInUp'),
        appset_vc_animation_duration(),
        appset_vc_spacing_options_param('margin', 'top'),
        appset_vc_spacing_options_param('margin', 'bottom'), 
        appset_vc_spacing_options_param('padding', 'left'),
        appset_vc_spacing_options_param('padding', 'right'),
         
    );
    foreach ( $newParamData as $key => $value ) {
        vc_update_shortcode_param( 'appset_counter_up', $value );
        vc_update_shortcode_param( 'appset_service_box', $value );       
    }
}


function appset_vc_style_options($name = "Style", $total = 3){

    $new_arr = array();
    $new_arr["None"] = '';
    for ($i = 1; $i <= $total; $i++) { 
        $new_arr["{$name} {$i}"] = $i;
    }
    return $new_arr;
}

function appset_vc_section_type_params( $param_name = '', $optiontype = "", $total = 3, $dep="" ){
    if( $param_name == '' ) return false;
    if( $optiontype == '' ) return false;

    return array(
             'type' => 'dropdown',
            'heading' => __( 'Choose '.$optiontype, 'appset' ),
            'param_name' => $param_name,
            'group' => 'Appset Settings',
            'value' => appset_vc_style_options($optiontype, $total),
            'description' => __( 'You need to add also hero element in this section, then it worked perfectly. Hero style select mean changes the default background, font size, spacing etc. of this section.', 'appset' ),
            'std'  => '',
            'edit_field_class' => 'vc_col-sm-4',
            'description' => '',
            'dependency' => array(
                'element' => 'section_type',
                'value' => $dep 
            ) 
        );
}

function appset_vc_row_type_params( $param_name = '', $optiontype = "", $total = 3, $dep="" ){
    if( $param_name == '' ) return false;
    if( $optiontype == '' ) return false;

    return array(
             'type' => 'dropdown',
            'heading' => __( 'Choose '.$optiontype, 'appset' ),
            'param_name' => $param_name,
            'group' => 'Appset Settings',
            'value' => appset_vc_style_options($optiontype, $total),
            'description' => __( 'You need to add also hero element in this section, then it worked perfectly. Hero style select mean changes the default background, font size, spacing etc. of this section.', 'appset' ),
            'std'  => '',
            'description' => '',
            'dependency' => array(
                'element' => 'row_type',
                'value' => $dep 
            ) 
        );
}

function appset_vc_column_type_params( $param_name = '', $optiontype = "", $total = 3, $dep="" ){
    if( $param_name == '' ) return false;
    if( $optiontype == '' ) return false;

    return array(
             'type' => 'dropdown',
            'heading' => __( 'Choose '.$optiontype, 'appset' ),
            'param_name' => $param_name,
            'group' => 'Appset Settings',
            'value' => appset_vc_style_options($optiontype, $total),
            'description' => __( 'You need to add also hero element in this section, then it worked perfectly. Hero style select mean changes the default background, font size, spacing etc. of this section.', 'appset' ),
            'std'  => '',
            'description' => '',
            'dependency' => array(
                'element' => 'column_inner_style',
                'value' => $dep 
            ) 
        );
}



if ( !function_exists( 'appset_get_posts_dropdown' ) ):
    function appset_get_posts_dropdown( $args = array( ) ) {
        global $wpdb, $post;
        $dropdown  = array( );
        $the_query = new WP_Query( $args );
        if ( $the_query->have_posts() ) {
            while ( $the_query->have_posts() ) {
                $the_query->the_post();
                $dropdown[ get_the_ID() ] = get_the_title();
            } //$the_query->have_posts()
        } //$the_query->have_posts()
        wp_reset_postdata();
        return $dropdown;
    }
endif;
if ( !function_exists( 'appset_get_terms' ) ):
    function appset_get_terms( $tax = 'category', $key = 'id' ) {
        $terms = array( );
        if ( !taxonomy_exists( $tax ) )
            return false;
        if ( $key === 'id' )
            foreach ( (array) get_terms( $tax, array(
                 'hide_empty' => false 
            ) ) as $term )
                $terms[ $term->term_id ] = $term->name;
        elseif ( $key === 'slug' )
            foreach ( (array) get_terms( $tax, array(
                 'hide_empty' => false 
            ) ) as $term )
                $terms[ $term->slug ] = $term->name;
        return $terms;
    }
endif;

add_filter( 'perch_modules/icon_type_options', 'appset_vc_icon_type_options' );
function appset_vc_icon_type_options($args){
    $args['Tonicons'] = 'tonicons';
    return $args;
}

add_filter( 'perch_modules/icon_type_std', 'appset_vc_icon_type_std' );
function appset_vc_icon_type_std($std){
    $std = 'tonicons';
    return $std;
}

add_filter('perch_modules/vc_icon_type_element', 'appset_vc_tonicon_icon_type_element', 30);
function appset_vc_tonicon_icon_type_element($args){
    $args = array(
        appset_vc_icon_set( array(), 'tonicons', 'icon_tonicons', 'ti-Line-Key-2', 'icon_type')
    );
    return $args;
}

function appset_vc_icontype_dropdown( $name = 'icon_type', $value = array( 'flaticon' => 'flaticon', 'Linecons' => 'linecons', 'Entypo' => 'entypo', 'Typicons' => 'typicons', 'Openiconic' => 'openiconic', 'Fontawesome' => 'fontawesome' ) ) {
    return array(
         'type' => 'dropdown',
        'heading' => __( 'Icon type', 'appset' ),
        'param_name' => $name,
        'description' => '',
        'value' => $value 
    );
}

function appset_vc_icon_set( $arr, $type, $name = 'icon_fontawesome', $value = '', $dependency = '' ) {
    $arr = array(
         'type' => 'iconpicker',
        'heading' => __( 'Icon', 'appset' ),
        'param_name' => $name,
        'value' => $value,
        'settings' => array(
             'emptyIcon' => true,
            'type' => $type,
            'iconsPerPage' => 4000 
        ),
        'description' => __( 'Select icon from library.', 'appset' ) ,
    );
    if ( $dependency != '' ) {
        $arr[ 'dependency' ][ 'element' ] = $dependency;
        $arr[ 'dependency' ][ 'value' ]   = $type;
    } //$dependency != ''
    return $arr;
}

add_filter( 'perch_modules/vc_icon_set', 'appset_vc_icon_set', 10, 5);

function appset_vc_animation_duration( $label = false, $default = 300 ){
    return array(
                 'type' => 'textfield',
                'value' => intval($default),
                'heading' => __( 'Animation delay', 'appset' ) ,
                'param_name' => 'animation_delay',
                'admin_label' => $label,
                'description' => __( 'Number only', 'appset' ),                
                'group' => __( 'Animation', 'appset' ),   
                'dependency' => array(
                    'element' => 'css_animation',
                    'value_not_equal_to' => 'none'
                )             
            );
}

function appset_vc_animation_type($std = ''){
    $output = vc_map_add_css_animation();
    $output['group'] = __( 'Animation', 'appset' );

    if( $std != '' ) $output['std'] = esc_attr($std);

    return $output;
}

add_filter( 'appset_vc_element_params', 'appset_vc_element_params_callback' );
function appset_vc_element_params_callback($args){
    $args['params'][] = appset_vc_animation_type();
    $args['params'][] = appset_vc_animation_duration();
    return $args;
}

function appset_animation_attr($css_animation, $animation_delay = 100){
    $output = '';
    if($css_animation == '') return $output;  
    $output .= ' data-wow-delay="'.intval($animation_delay).'ms"';

    return $output;
}
function appset_vc_tag_options(){
    $arr = array(
        __('Default', 'appset') => '',
        __('H1', 'appset') => 'h1',
        __('H2', 'appset') => 'h2',
        __('H3', 'appset') => 'h3',
        __('H4', 'appset') => 'h4',
        __('H5', 'appset') => 'h5',
        __('H6', 'appset') => 'h6',
        __('P', 'appset') => 'p',                
        __('Span', 'appset') => 'span',       
        __('Small', 'appset') => 'small',       
        __('Strong', 'appset') => 'strong', 
        __('Div', 'appset') => 'div',
        __('Footer', 'appset') => 'footer', 
         __('Underline', 'appset') => 'u',      
        __('Blockquote', 'appset') => 'blockquote',               
        __('Address', 'appset') => 'address',       
        __('em', 'appset') => 'em',       
        __('Del', 'appset') => 'del',       
        __('Mark', 'appset') => 'mark',       
        __('S', 'appset') => 's',       
        __('Ins', 'appset') => 'ins',       
        __('Code', 'appset') => 'code',       
        __('Pre', 'appset') => 'pre',       
        __('Var', 'appset') => 'var',       
        __('kbd', 'appset') => 'kbd',       
        __('samp', 'appset') => 'samp',       
             
    );

    return $arr;
}
function appset_vc_size_class_options(){
    $arr = array(
        __('Default', 'appset') => '',
        __('Huge', 'appset') => 'huge',
        __('Extra large', 'appset') => 'xl',
        __('Large', 'appset') => 'lg',
        __('Medium', 'appset') => 'md',
        __('Small', 'appset') => 'sm',
        __('Extra small', 'appset') => 'xs',
    );

    return $arr;
}

function appset_vc_weight_class_options(){
    $arr = array(
        __('Default', 'appset') => '',
        __('Font weight thin', 'appset') => 'txt-300',    
        __('Font weight normal', 'appset') => 'txt-400',
        __('Font weight 500', 'appset') => 'txt-500',    
        __('Font weight 600', 'appset') => 'txt-600',    
        __('Font weight Bold', 'appset') => 'txt-700',    
        __('Font weight 800', 'appset') => 'txt-800',    
        __('Font weight 900', 'appset') => 'txt-900',  
         __('Section id', 'appset') => 'section-id',  
    );

    return $arr;
}
function appset_vc_tag_options_param($param_name, $heading='', $std = '', $group='', $dep=array()){    
    
    $arr = array(
                'type' => 'dropdown',
                'heading' => $heading,
                'param_name' => $param_name,
                'value' => appset_vc_tag_options(),
                'group' => __( 'Design option', 'appset' ),
                'save_always' => true,
            );
    if( $std != '' ) $arr['std'] = $std;
    if( $group != '' ) $arr['group'] = $group;
    if( !empty($dep) ) $arr['dependency'] = $dep;

    return $arr;
}
function appset_vc_size_options_param($param_name, $heading='', $std = '', $group='', $dep=array()){    
   
    $arr = array(
                'type' => 'dropdown',
                'heading' => $heading,
                'param_name' => $param_name,
                'value' => appset_vc_size_class_options(),
                'group' => __( 'Design option', 'appset' ),
            );
    if( $std != '' ) $arr['std'] = $std;
    if( $group != '' ) $arr['group'] = $group;
    if( !empty($dep) ) $arr['dependency'] = $dep;
    
    return $arr;
}

function appset_vc_weight_options_param($param_name, $heading='', $std = '', $group='', $dep=array()){    
    $arr = array(
                'type' => 'dropdown',
                'heading' => $heading,
                'param_name' => $param_name,
                'value' => appset_vc_weight_class_options(),
                'group' => __( 'Design option', 'appset' ),
            );
    if( $std != '' ) $arr['std'] = $std;
    if( $group != '' ) $arr['group'] = $group;
    if( !empty($dep) ) $arr['dependency'] = $dep;
    
    return $arr;
}

function appset_vc_color_options_param($param_name, $heading='', $std = '', $group='', $dep=array()){    
    $arr = array(
                'type' => 'dropdown',
                'heading' => $heading,
                'param_name' => $param_name,
                'value' => appset_vc_color_options(true),
                'group' => __( 'Design option', 'appset' ),
            );
    if( $std != '' ) $arr['std'] = $std;
    if( $group != '' ) $arr['group'] = $group;
    if( !empty($dep) ) $arr['dependency'] = $dep;
    
    return $arr;
}

function appset_vc_heading_size_options(){
    $arr = array(
        __('H2 Normal', 'appset') => 'h2:h2-normal',
        __('H2 Huge', 'appset') => 'h2:h2-huge',
        __('H2 extra large', 'appset') => 'h2:h2-xl',
        __('H2 Large', 'appset') => 'h2:h2-lg',
        __('H2 Medium', 'appset') => 'h2:h2-md',
        __('H2 small', 'appset') => 'h2:h2-sm',
        __('H2 Extra small', 'appset') => 'h2:h2-xs',
        
        __('H3 Normal', 'appset') => 'h3:h3-normal',
        __('H3 extra large', 'appset') => 'h3:h3-xl',
        __('H3 Large', 'appset') => 'h3:h3-lg',
        __('H3 Medium', 'appset') => 'h3:h3-md',
        __('H3 small', 'appset') => 'h3:h3-sm',
        __('H3 Extra small', 'appset') => 'h3:h3-xs',

         __('H4 extra large', 'appset') => 'h4:h4-xl',
        __('H4 Large', 'appset') => 'h4:h4-lg',
        __('H4 Medium', 'appset') => 'h4:h4-md',
        __('H4 small', 'appset') => 'h4:h4-sm',
        __('H4 Extra small', 'appset') => 'h4:h4-xs',

        __('H5 extra large', 'appset') => 'h5:h5-xl',
        __('H5 Large', 'appset') => 'h5:h5-lg',
        __('H5 Medium', 'appset') => 'h5:h5-md',
        __('H5 small', 'appset') => 'h5:h5-sm',
        __('H5 Extra small', 'appset') => 'h5:h5-xs',
    );

    return $arr;
}

function appset_vc_icon_class_options(){
    $arr = array(
        __('None', 'appset') => 'none',
        __('Rotation 90 deg', 'appset') => 'fa-rotate-90',
         __('Rotation 180 deg', 'appset') => 'fa-rotate-180',
         __('Rotation 270 deg', 'appset') => 'fa-rotate-270',
         __('Mirrors icon horizontally', 'appset') => 'fa-flip-horizontal',
         __('Mirrors icon vertically', 'appset') => 'fa-flip-vertical',
         __('Spinner', 'appset') => 'fa-spin',
    );
    return $arr;
}
function appset_vc_underline_color_options(){
    $arr = array(
        __('None', 'appset') => 'none',
        __('Image', 'appset') => 'underline-image',
         __('Font weight bold', 'appset') => 'font-weight-bold',
         __('Font weight thin', 'appset') => 'txt-300',
         __('Font weight thiner', 'appset') => 'txt-100',
         __('Italic text', 'appset') => 'font-italic',
         __('Indicates uppercased text', 'appset') => 'text-uppercase',
    );

    $colors = appset_default_color_classes();
    foreach ($colors as $key => $value) {
        $color_name = $value['label'];
        $color_class = 'underline-'.$key;
        $arr[$color_name] = $color_class;
    }

    return $arr;
}
function appset_vc_global_color_options(){
    $arr = array();

    $colors = appset_default_color_classes();
    foreach ($colors as $key => $value) {
        $color_name = $value['label'];
        $color_class = $key;
        $arr[$color_name] = $color_class;
    }

    return $arr;
}

function appset_vc_text_size_options(){
    return array(
        __('Default', 'appset') => '',
        __('Small', 'appset') => 'p-sm',
        __('Medium', 'appset') => 'p-md',
        __('large', 'appset') => 'p-lg',
        __('Font weight bold', 'appset') => 'p-lg font-weight-bold',
         __('Italic text', 'appset') => 'p-lg font-italic',
         __('Indicates uppercased text', 'appset') => 'p-lg text-uppercase',
    );
}

function appset_vc_spacing_options($type='padding', $pos = 'bottom'){
    $total = apply_filters('appset_vc_spacing_total', 120);
    $arr = array();
    $prefix = ($type == 'padding')? 'p' : 'm';
    $_pos = ($pos == 'bottom')? 'b' : 't';
    $prefix = $prefix.$_pos.'-';
    $arr = array(
        __('Inherit', 'appset') => '',     
    );
    for ($i=0; $i <= $total; $i+=5) { 
        $name = ucfirst($type).' '.$pos. ' '.$i.'px';
       $arr[$name] = $prefix.$i; 
    }
    return $arr;
}


function appset_vc_spacing_options_param($type = 'padding', $pos = 'bottom', $name = ''){
    $prefix = ($type == 'padding')? 'p' : 'm';
    $param_name = $prefix.$pos;
    $param_name = ( $name != '' )? $name : $param_name;
    $heading = ucfirst($type).' '.$pos;
    return array(
                'type' => 'dropdown',
                'heading' => $heading,
                'param_name' => $param_name,
                'value' => appset_vc_spacing_options($type, $pos),
                'group' => __( 'Spacing option', 'appset' ),
                'edit_field_class' => 'vc_col-sm-6', 
            );
}

function appset_vc_content_list_group(){
    return array(
            'type' => 'param_group',
            'save_always' => true,
            'heading' => __( 'Content list', 'appset' ),
            'param_name' => 'content_list',
            'value' => urlencode( json_encode( array(
                array( 'title' => 'Fully Responsive Design' ),
                array( 'title' => 'Bootstrap 4.0 Based' ),
                array( 'title' => 'Google Analytics Ready' ),
                array( 'title' => 'Cross Browser Compatability' ),
                array( 'title' => 'Developer Friendly Commented Code' ),
                array( 'title' => 'and much more...' ),
            ) ) ),
            'params' => array(
                 array(
                    'type' => 'textarea',
                    'heading' => __( 'Title', 'appset' ),
                    'param_name' => 'title',
                    'description' => '',
                    'value' => '',
                    'admin_label' => true 
                ),
            ),            
            'dependency' => array(
                'element' => 'enable_list',
                'value' => 'yes'
            )  
        );
}

if( !function_exists('appset_target_param_list') ):
function appset_target_param_list() {
    return array(
        __( 'Same window', 'appset' ) => '_self',
        __( 'New window', 'appset' ) => '_blank',
    );
}
endif;


function appset_vc_counter_group(){
    return array(
        'type' => 'param_group',
        'save_always' => true,
        'heading' => __( 'Counter up', 'appset' ),
        'param_name' => 'counter_group',
        'value' => urlencode( json_encode( array(
            array(
                 'title' => 'Happy Clients',
                'count' => '438',
                'prefix' => '3,',
            ),
            array(
                 'title' => 'Tickets Closed',
                'count' => '263',
                'prefix' => '1,',
            ),
        ) ) ),
        'params' => array(
            array(
                 'type' => 'textfield',
                'heading' => __( 'Counter Prefix', 'appset' ),
                'param_name' => 'prefix',
                'description' => '',
                'value' => '3,',
                'admin_label' => true 
            ),
            array(
                 'type' => 'textfield',
                'heading' => __( 'Count', 'appset' ),
                'param_name' => 'count',
                'description' => 'Number only',
                'value' => '' ,
                'admin_label' => true 
            ),
             array(
                 'type' => 'textfield',
                'heading' => __( 'Title', 'appset' ),
                'param_name' => 'title',
                'description' => '',
                'value' => '',
                'admin_label' => true 
            ),
            
        ),
        'dependency' => array(
            'element' => 'display',
            'value' => 'counter'
        ),
        'group' => __( 'Content bottom', 'appset' ),  
    );
}

function appset_vc_techs_group(){
    return array(
        'type' => 'param_group',
        'save_always' => true,
        'heading' => __( 'Techs', 'appset' ),
        'param_name' => 'techs_group',
        'value' => urlencode( json_encode( array(
            array(
                 'title' => 'HTML5',
                'icon' => 'fa fa-html5',
                'image' => ''
            ),
            array(
                 'title' => 'CSS3',
                'icon' => 'fa fa-css3',
                'image' => ''
            ),
            array(
                 'title' => 'jsfiddle',
                'icon' => 'fa fa-jsfiddle',
                'image' => ''
            ),
            array(
                 'title' => 'git',
                'icon' => 'fa fa-git',
                'image' => ''
            ),
            array(
                 'title' => 'WordPress',
                'icon' => 'fa fa-wordpress',
                'image' => ''
            ),
            array(
                 'title' => 'mixcloud',
                'icon' => 'fa fa-mixcloud',
                'image' => ''
            ),
        ) ) ),
        'params' => array(
             array(
                'type' => 'textfield',
                'heading' => __( 'Title', 'appset' ),
                'param_name' => 'title',
                'description' => '',
                'value' => '',
                'admin_label' => true 
            ),
             appset_vc_icon_set( 'fontawesome', 'icon' ),
             array(
                'type' => 'image_upload',
                'heading' => __( 'Icon Image', 'appset' ),
                'param_name' => 'image',
                'description' => 'You can use image instead of Icon',
                'value' => '' 
            ),
        ),
        'dependency' => array(
            'element' => 'display',
            'value' => 'techs'
        ),
        'group' => __( 'Content bottom', 'appset' ),  
    );
}

function appset_vc_strategy_list_group($group = true){
    $output = array(
            'type' => 'param_group',
            'save_always' => true,
            'heading' => __( 'Content group', 'appset' ),
            'param_name' => 'strategy_list',
            'value' => urlencode( json_encode( array(
                array(
                     'title' => 'Vitae auctor integer congue magna at pretium purus pretium ligula rutrum luctus risus velna auctor congue tempus undo magna ',
                ),
                array(
                     'title' => 'An enim nullam tempor sapien gravida donec enim ipsum porta blandit justo integer odio velna vitae auctor integer luctus',
                ),
            ) ) ),
            'params' => array(
                 array(
                    'type' => 'textarea',
                    'heading' => __( 'Description', 'appset' ),
                    'param_name' => 'title',
                    'description' => '',
                    'value' => '',
                    'admin_label' => true 
                ),
            ),
        );

    if($group) $output['group'] = __( 'Content', 'appset' );

    return $output;
}

function appset_vc_get_strategy_list( $type = 'list', $paramsArr = array() , $duration = 400  ){
    if( empty($paramsArr) ) return false;
   
    if( $type == 'list' ){
        echo '<ul class="content-list">';
            foreach ($paramsArr as $key => $value): 
                extract($value);                                    
                echo '<li class="wow fadeInUp" data-wow-delay="'.intval($duration).'ms">';
                    echo wpautop($title);                 
                echo '</li>';
                $duration = $duration + 100;
            endforeach;
        echo '</ul>';
    }else{
        foreach ($paramsArr as $key => $value): 
            extract($value);                                    
            echo '<div class="wow fadeInUp" data-wow-delay="'.intval($duration).'ms">';
                echo wpautop($title);                 
            echo '</div>';
            $duration = $duration + 100;
        endforeach;
    }
}

function appset_vc_element_display_option(){
    return array(
                    'None' => 'none',
                    'Video link' => 'video',                    
                    'Counter' => 'counter',
                    'Techs' => 'techs',
                );
}

function appset_vc_element_icon_size(){
    return array(
                    'Default' => 'icon',
                    'Extra small' => 'xs',                    
                    'Small' => 'sm',
                    'Medium' => 'md',
                    'Large' => 'lg',
                    '2X size' => '2x',
                    '3X size' => '3x',
                    '5X size' => '5x',
                    '7X size' => '7x',
                    '10X size' => '10x',
                );
}

function appset_vc_get_content_list_group( $paramsArr = array(), $animation = '', $delay = '100'){
    if(empty($paramsArr)) return false;
    echo '<ul class="content-list">';
    foreach ($paramsArr as $key => $value):                     
        echo '<li class="wow '.esc_attr($animation).'" data-wow-delay="'. intval($delay).'ms">'.esc_attr($value['title']).'</li>';
        $delay = $delay + 100; 
    endforeach; 
    echo '</ul>';
}

add_filter( 'perch_modules/service_style', 'appset_service_style' );
function appset_service_style( $args ){
    $total = 6;
    $prefix = 'fbox-';
    $label_prefix = __( 'Feature box', 'appset' );
    $new_arr = array();
    for ($i=1; $i <= $total; $i++) { 
        $new_arr[$label_prefix.' '.$i] = $prefix.$i;
    }
    $args = array_merge($args, $new_arr);
    return $args;
}

add_filter( 'appset_vc_templates_param_group', 'appset_vc_templates_param_group' );
function appset_vc_templates_param_group($output){
    $paramsArr = (function_exists('vc_param_group_parse_atts'))? vc_param_group_parse_atts($output) : array();
    $new_array = array();
    if( !empty($paramsArr) ){
        foreach ($paramsArr as $key => $value) {
            $new_array[] = appset_vc_image_url_filter($value);
        }
    }
    return urlencode(json_encode($new_array));
}

function appset_vc_image_url_filter($arr){
    if( !empty($arr) ){

    }
    return $arr;
}


/**
* vc_map default values
* @param array
* @return array
*/
function appset_vc_get_params_value($args = array(), $_content = NULL){
    $array = array();
    if( !isset($args['base']) || !isset($args['params']) ){
        return $array;
    }

    $newarray = array();
    $map_arr = $args['params'];
    foreach ( $map_arr as $key => $value) {
        $param_name = isset($value['param_name'])? $value['param_name'] : '';
            $std = '';
            if(isset($value['value']) ){
                if( is_array($value['value']) ) {                    
                    if(!isset($value['std'])){
                        $array = $value['value']; reset($array); $std = key($array);
                    }else{
                        $std = $value['std'];
                    }
                }else {
                    $std = $value['value'];
                }
            }
            $std = isset($value['std'])? $value['std'] : $std;

            if( $param_name != '' ){
                $newarray[$param_name] = $std;
            }
    }
    $newarray['content'] = $_content;


    if( !empty($newarray) ) $array = $newarray;

    return $array;
}


if ( function_exists( 'vc_set_as_theme' ) ):
    vc_set_as_theme( $disable_updater = false );
    $list = array(
         'page',
        'post',
        'team',
        'portfolio',
        'service',
        'job' 
    );
    vc_set_default_editor_post_types( $list );
endif;

add_action( 'vc_after_init_base', 'add_more_custom_layouts' );
function add_more_custom_layouts() {
  global $vc_row_layouts;
  $new_layouts = array(
      'cells' => '512_112_12',
      'mask' => '424',
      'title' => 'Custom 5/12 + 1/12 + 6/12',
      'icon_class' => '512_112_12' 
    );
  array_push( $vc_row_layouts,  $new_layouts );

  $new_layouts = array(
      'cells' => '12_112_512',
      'mask' => '424',
      'title' => 'Custom 6/12 + 1/12 + 5/12',
      'icon_class' => '12_112_512' 
    );
  array_push( $vc_row_layouts,  $new_layouts );

  $new_layouts = array(
      'cells' => '112_56_112',
      'mask' => '424',
      'title' => 'Custom 1/12 + 10/12 + 1/12',
      'icon_class' => '112_56_112' 
    );
  array_push( $vc_row_layouts,  $new_layouts );

  
}

/* global vc include files */
foreach ( glob( APPSET_DIR . "/vc-extends/*.php" ) as $filename ) {
    include $filename;
} //glob( APPSET_DIR . "/admin/vc-extends/*.php" ) as $filename
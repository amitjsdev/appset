<?php
function appset_get_typography_font_options(){
	$arr = array();
	
	$fonts = array(
		'Roboto:300,regular,500,700,900',
		'Montserrat:300,regular,500,600,700,800,900',
	);

	

	return $fonts;
}

if ( ! function_exists( 'appset_fonts_url' ) ) :
/**
 * Register Google fonts for Twenty Fifteen.
 *
 * @return string Google fonts URL for the theme.
 */
function appset_fonts_url() {
	$fonts_url = '';
	$fonts     = array();

	/*
	 * Translators: If there are characters in your language that are not supported
	 */
	$fonts = appset_get_typography_font_options();
	

	$subsets   = 'latin,latin-ext';
	$subset = 'no-subset';

	if ( 'cyrillic' == $subset ) {
		$subsets .= ',cyrillic,cyrillic-ext';
	} elseif ( 'greek' == $subset ) {
		$subsets .= ',greek,greek-ext';
	} elseif ( 'devanagari' == $subset ) {
		$subsets .= ',devanagari';
	} elseif ( 'vietnamese' == $subset ) {
		$subsets .= ',vietnamese';
	}

	if ( $fonts ) {
		$fonts_url = add_query_arg( array(
			'family' => urlencode( implode( '|', $fonts ) ),
			'subset' => urlencode( $subsets ),
		), '//fonts.googleapis.com/css' );
	}

	return $fonts_url;
}
endif;

/**
 * JavaScript Detection.
 *
 * Adds a `js` class to the root `<html>` element when JavaScript is detected.
 *
 */
function appset_javascript_detection() {
	echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
}
add_action( 'wp_head', 'appset_javascript_detection', 0 );

// Register Style
function appset_styles() {

	wp_dequeue_style( 'ot-google-fonts' );
	wp_register_style( 'appset-google-fonts', appset_fonts_url(), array(), null );
	wp_enqueue_style( 'appset-google-fonts' );
	

	wp_enqueue_style( 'bootstrap', APPSET_URI. '/css/bootstrap.min.css', false, '4.0.0' );
	wp_enqueue_style( 'fa-svg-with-js', APPSET_URI. '/css/fa-svg-with-js.css', false, '1.0.0' );			
	wp_enqueue_style( 'tonicons' );
	wp_enqueue_style( 'flaticon' );
	wp_enqueue_style( 'fontawesome' );
	wp_enqueue_style( 'magnific-popup', APPSET_URI. '/css/magnific-popup.css', false, '1.0.0' );		
	wp_enqueue_style( 'slick', APPSET_URI. '/css/slick.css', false, '1.0.0' );		
	wp_enqueue_style( 'slick-theme', APPSET_URI. '/css/slick-theme.css', false, '1.0.0' );		
	wp_enqueue_style( 'appset-flexslider', APPSET_URI. '/css/flexslider.css', false, '1.0.0' );
	wp_enqueue_style( 'owl-carousel', APPSET_URI. '/css/owl.carousel.min.css', false, '1.0.0' );
	wp_enqueue_style( 'owl-theme-default', APPSET_URI. '/css/owl.theme.default.min.css', false, '1.0.0' );
	wp_enqueue_style( 'animate', APPSET_URI. '/css/animate.css', false, '1.0.0' );	
	wp_enqueue_style( 'selectize-bootstrap4', APPSET_URI. '/css/selectize.bootstrap4.css', false, '1.0.0' );	
	wp_enqueue_style( 'appset-spinner', APPSET_URI. '/css/spinner.css', false, '1.0.0' );
	

	wp_enqueue_style( 'appset-default-style', APPSET_URI. '/css/style.css', false, '1.0.0' );
	wp_enqueue_style( 'appset-style', get_stylesheet_uri(), false, '1.0.0' );
	
	wp_enqueue_style( 'appset-responsive', APPSET_URI. '/css/responsive.css', array('appset-style'), '1.0.1.3' );

	$appset_layout_style = appset_get_option( 'appset_layout_style', 'rounded' );
	if( $appset_layout_style != 'semirounded' ){
		wp_enqueue_style( 'appset-layout-'.$appset_layout_style, APPSET_URI. '/css/appset-'.$appset_layout_style.'.css', array('appset-style'), '1.0.0' );
	}
}
add_action( 'wp_enqueue_scripts', 'appset_styles' );

/**
 * Output an Underscore template for generating CSS for the color scheme.
 *
 * The template generates the css dynamically for instant display in the Customizer
 * preview.
 *
 */
function appset_inline_css_style() {	
	wp_add_inline_style( 'appset-style', appset_get_dynamic_header_css() );	
  wp_add_inline_style( 'appset-default-style', appset_dynamic_general_style_css() );
  wp_add_inline_style( 'bootstrap', appset_bootstrap_style_css() );  
  if(function_exists('is_woocommerce')){
    wp_add_inline_style( 'woocommerce-general', appset_woocommerce_general_style_css() );
  }
}
add_action( 'wp_enqueue_scripts', 'appset_inline_css_style' );


// Register Script
function appset_scripts() {
	
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	wp_register_script( 'appset-map', APPSET_URI .'/js/appset-map.js', array( 'jquery' ), '1.0.0', true );
	$key = 'AIzaSyC3VridlI2w6LmX_55OQQ4airseVZo-uVI';
	$key = appset_get_option( 'google_map_api', $key );
	wp_register_script( 'googleapis', '//maps.googleapis.com/maps/api/js?key='.esc_attr($key).'&callback=appsetinitMap', array( 'jquery', 'appset-map' ), '1.0.0', true );	

	
	

	wp_register_script( 'imgLiquid', APPSET_URI .'/js/imgLiquid-min.js', array( 'jquery' ), '1.0.0', true ); 	
	wp_enqueue_script( 'bootstrap', APPSET_URI .'/js/bootstrap.min.js', array( 'jquery' ), '4.1.0', true ); 	
	wp_enqueue_script( 'fontawesome-all', APPSET_URI .'/js/fontawesome-all.min.js', array('jquery'),'1.0.0',true );
	wp_enqueue_script( 'v4-shims', APPSET_URI .'/js/fa-v4-shims.min.js', array( 'jquery' ), '1.0.0', true );
	wp_enqueue_script( 'modernizr-custom', APPSET_URI .'/js/modernizr.custom.js', array('jquery'),'1.0.0',true );	
	wp_enqueue_script( 'jquery-easing', APPSET_URI .'/js/jquery.easing.js', array('jquery'),'1.0.0',true );
	wp_enqueue_script( 'jquery-stellar', APPSET_URI .'/js/jquery.stellar.min.js', array('jquery'),'1.0.0',true );
	wp_enqueue_script( 'jquery-scrollto', APPSET_URI .'/js/jquery.scrollto.js', array('jquery'),'1.0.0',true );
	wp_enqueue_script( 'jquery-appear', APPSET_URI .'/js/jquery.appear.js', array('jquery'),'1.0.0',true );
	wp_enqueue_script( 'jquery-superslides', APPSET_URI .'/js/jquery.superslides.js', array('jquery'),'1.0.0',true );
	wp_enqueue_script('jquery-masonry');
	wp_enqueue_script( 'imagesloaded-pkgd', APPSET_URI .'/js/imagesloaded.pkgd.min.js', array('jquery'),'4.1.4',true );
	wp_enqueue_script( 'vidbg', APPSET_URI .'/js/vidbg.min.js', array('jquery'),'0.5.1',true );
	wp_enqueue_script( 'isotope-pkgd', APPSET_URI .'/js/isotope.pkgd.min.js', array('jquery'),'1.0.0',true );
	wp_enqueue_script( 'jquery-flexslider', APPSET_URI .'/js/jquery.flexslider.js', array('jquery'),'1.0.0',true );
	
	wp_register_script( 'owl-carousel', APPSET_URI .'/js/owl.carousel.min.js', array('jquery'),'1.0.0',true );
	wp_enqueue_script( 'owl-carousel');
	wp_enqueue_script( 'slick', APPSET_URI .'/js/slick.min.js', array('jquery'),'1.0.0',true );
	wp_enqueue_script( 'selectize', APPSET_URI .'/js/selectize.min.js', array('bootstrap'),'1.0.0',true );
	wp_enqueue_script( 'wow', APPSET_URI .'/js/wow.js', array('jquery'),'1.0.0',true );
	wp_enqueue_script( 'jquery-magnific-popup', APPSET_URI .'/js/jquery.magnific-popup.min.js', array('jquery'),'1.0.0',true );
	wp_register_script( 'front_enqueue_js', APPSET_URI.'/js/front_enqueue_js.js', array('jquery'),'1.0.0',true );

	wp_enqueue_script( 'appset-custom', APPSET_URI . '/js/custom.js', array( 'owl-carousel' ), '1.0.1.3', true );
	wp_register_script( 'jquery-countdown', APPSET_URI .'/js/jquery.countdown.min.js', array( 'appset-custom' ), '1.0.1.3', true );
	 

	$arr = array( 
		'ajaxurl' => admin_url( 'admin-ajax.php' ),
		'APPSET_URI' => APPSET_URI,
		'APPSET_DIR' => APPSET_DIR,
		'animation' => appset_get_option( 'appset_animation', 'on' )
		);
	wp_localize_script( 'appset-custom', 'APPSET', $arr );

}
add_action( 'wp_enqueue_scripts', 'appset_scripts' );
